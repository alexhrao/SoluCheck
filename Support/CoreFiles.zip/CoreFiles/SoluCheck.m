function varargout = SoluCheck(varargin)
% SOLUCHECK Code for SoluCheck Platform
%      SOLUCHECK, by itself, creates a new SOLUCHECK or raises the existing
%      singleton.
% 
%      
%      For More help, see the SoluCheck Documentation, which should have
%      been included with your install of SoluCheck. Alternatively, you can
%      contact SoluCheck Services at SoluCheck@gmail.com.
%
% See also: AdvancedOptions, SoluCheckEngine

% Last Modifiedz by GUIDE v2.5 27-Oct-2015 23:15:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SoluCheck_OpeningFcn, ...
                   'gui_OutputFcn',  @SoluCheck_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SoluCheck is made visible.
function SoluCheck_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<VANUS,*INUSL>
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SoluCheck (see VARARGIN)

% Initialize starting variables:
uimenu()
bFirstTime = true;
strOldDir = cd();
setappdata(findobj('Tag', 'uiBSoluCheck'), 'bFirstTime', bFirstTime);
vecOldSize = [1000 650];
warning('off', 'all');
if ~isappdata(hObject, 'stcSwitches')
    stcSwitches = struct('Profiler', false, ...
                         'Timing', false, ...
                         'LoadDatabase', false, ...
                         'LoadVariables', false, ...
                         'Details', false, ...
                         'MaxMin', false, ...
                         'Exempt', false, ...
                         'ArrSize', false, ...
                         'Notifications', false, ...
                         'Arguments', false, ...
                         'PlotTesting', false, ...
                         'FileTesting', false, ...
                         'ImageTesting', false, ...
                         'VariableIn', false, ...
                         'VariableOut', false);
                     
    [arrSound1, arrBitRate1] = audioread('Start.mp3');
    [arrSound2, arrBitRate2] = audioread('Pass1.mp3');
    [arrSound3, arrBitRate3] = audioread('Pass2.mp3');
    [arrSound4, arrBitRate4] = audioread('Pass3.mp3');
    [arrSound5, arrBitRate5] = audioread('Pass4.mp3');
    [arrSound6, arrBitRate6] = audioread('Fail1.mp3');
    [arrSound7, arrBitRate7] = audioread('Fail2.mp3');
    [arrSound8, arrBitRate8] = audioread('Fail3.mp3');
    [arrSound9, arrBitRate9] = audioread('Error1.mp3');
    [arrSound10, arrBitRate10] = audioread('Error2.mp3');
    [arrSound11, arrBitRate11] = audioread('Error3.mp3');
    stcSounds = struct('Start', {{arrSound1, arrBitRate1}, [], [], []}, ...
                       'Pass', {{arrSound2, arrBitRate2}, {arrSound3, arrBitRate3}, {arrSound4, arrBitRate4}, {arrSound5, arrBitRate5}}, ...
                       'Fail', {{arrSound6, arrBitRate6}, {arrSound7, arrBitRate7}, {arrSound8, arrBitRate8}, []}, ...
                       'Error', {{arrSound9, arrBitRate9}, {arrSound10, arrBitRate10}, {arrSound11, arrBitRate11}, []});

    setappdata(findobj('Tag', 'uiBSoluCheck'), 'stcSwitches', stcSwitches);
    setappdata(findobj('Tag', 'uiBSoluCheck'), 'stcSounds', stcSounds);
end
setappdata(findobj('Tag', 'uiBSoluCheck'), 'strOldDir', strOldDir);
setappdata(findobj('Tag', 'uiBSoluCheck'), 'vecOldSize', vecOldSize);
setappdata(findobj('Tag', 'uiBSoluCheck'), 'bFirstTime', bFirstTime);
objProgressBar = javacomponent('javax.swing.JProgressBar', [10 30 342 20]);
objProgressBar.setStringPainted(true);
objProgressBar.setString('0.00%');
objProgressBar.setMaximum(100);
objProgressBar.setMinimum(1);
objProgressBar.setValue(0);
objProgressBar.setBackground(java.awt.Color(1,1,1));
objProgressBar.setForeground(java.awt.Color(0,.75,0));
setappdata(findobj('Tag', 'uiBSoluCheck'), 'objProgressBar', objProgressBar);
setappdata(findobj('Tag', 'uiBSoluCheck'), 'fhpbBTest_Callback', @pbBTest_Callback);
% Choose default command line output for SoluCheck
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
% UIWAIT makes SoluCheck wait for user response (see UIRESUME)
% uiwait(handles.uiBSoluCheck);

% --- Outputs from this function are returned to the command line.
function varargout = SoluCheck_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure

% Try to output our handle; if we can't then we exited violently!
try
    varargout{1} = handles.output;
catch ME
    fprintf('SoluCheck has exited violently.\n%s', ME.identifier)
end

function tbBFilePath_Callback(hObject, eventdata, handles) %#ok<*INUSD,*DEFNU>
% hObject    handle to tbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBFilePath as text
%        str2double(get(hObject,'String')) returns contents of tbBFilePath as a double

% --- Executes during object creation, after setting all properties.
function tbBFilePath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tbBSolutionPath_Callback(hObject, eventdata, handles)
% hObject    handle to tbBSolutionPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBSolutionPath as text
%        str2double(get(hObject,'String')) returns contents of tbBSolutionPath as a double


% --- Executes during object creation, after setting all properties.
function tbBSolutionPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBSolutionPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pbBFilePath.
function pbBFilePath_Callback(hObject, eventdata, handles)
% hObject    handle to pbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Initialize starting variables:
bFirstTime = getappdata(findobj('Tag', 'uiBSoluCheck'), 'bFirstTime');
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
stcSounds = getappdata(hSoluCheck, 'stcSounds');
stcSwitches = getappdata(hSoluCheck, 'stcSwitches');
% Get the user's file path; will return 0 if the user cancelled!
[sFileName, sFilePath] = uigetfile('*.m');
setappdata(findobj('Tag', 'uiBSoluCheck'), 'sFileName', sFileName);
setappdata(findobj('Tag', 'uiBSoluCheck'), 'sFilePath', sFilePath);
sOriginalFileName = get(handles.tbBFilePath, 'string');
if sFilePath ~= 0
    % Tell the user that we are loading the specified file
    set(handles.stBTestResults, 'String', 'Loading...', 'ForegroundColor', 'black', 'Background', [.94 .94 .94]);
    pause('on');
    pause(1);
    pause('off');
    cd(sFilePath);
    set(handles.stBFunctionName, 'string', sFileName);
    set(handles.tbBFilePath, 'string', [sFilePath sFileName]);
    if strcmp(get(handles.tbBSolutionPath, 'string'), 'Select your solution file...')
        set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
        set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
        sSolutionPath = sFilePath;
        setappdata(findobj('Tag','uiBSoluCheck'), 'sSolutionPath', sSolutionPath);
        sSolutionName = [sFileName(1:end-2) '_soln.p'];
        setappdata(findobj('Tag', 'uiBSoluCheck'), 'sSolutionName', sSolutionName);
    elseif strcmp([sOriginalFileName(1:end-2) '_soln.p'], get(handles.tbBSolutionPath, 'string'))
        set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
        sSolutionPath = sFilePath;
        setappdata(findobj('Tag','uiBSoluCheck'), 'sSolutionPath', sSolutionPath);
        sSolutionName = [sFileName(1:end-2) '_soln.p'];
        setappdata(findobj('Tag', 'uiBSoluCheck'), 'sSolutionName', sSolutionName);
    end
    % Provide file path to outside applications:
    setappdata(handles.uiBSoluCheck, 'cFile', {sFilePath, sFileName});
    try
        % Try to determine how many arguments; if we can't tell the
        % user to select a valid file!
        addpath(sFilePath);
        iNargin = nargin([sFilePath sFileName]);
        setappdata(handles.uiBSoluCheck, 'iNargin', iNargin);
    catch
        strResult = sprintf('Loading File %s...Failed! Please select a valid function file!', sFileName);
        set(handles.stBTestResults, 'string', 'Please select a valid function file!', 'BackgroundColor', 'Yellow');
        if stcSwitches.Details
            hViewer = findobj('Tag', 'uiVViewer');
            hViewer = hViewer.Children(3);
            strOld = get(hViewer, 'String');
            [intLines, ~] = size(strOld);
            cellViewer = cell(1, intLines + 1);
            for i = 1:intLines
                cellViewer{i} = strOld(i, :);
            end
            cellViewer(2:end) = cellViewer(1:end-1);
            cellViewer{1} = strResult;
            set(hViewer, 'String', strjoin(cellViewer, '\n'));
        end
        return
    end
    % Check to make sure no varargin
    if iNargin < 0
        strResult = sprintf('Loading File %s...Failed! Please select a function that does NOT take in varargin!', sFileName);
        set(handles.stBTestResults, 'string', 'Please select a function that does NOT take in a variable number of inputs!', 'BackgroundColor', 'Yellow');
        if stcSwitches.Details
            hViewer = findobj('Tag', 'uiVViewer');
            hViewer = hViewer.Children(3);
            strOld = get(hViewer, 'String');
            [intLines, ~] = size(strOld);
            cellViewer = cell(1, intLines + 1);
            for i = 1:intLines
                cellViewer{i} = strOld(i, :);
            end
            cellViewer(2:end) = cellViewer(1:end-1);
            cellViewer{1} = strResult;
            set(hViewer, 'String', strjoin(cellViewer, '\n'));
        end
        return
    end
    % Prep SoluCheck for testing, and change to solution file path if
    % it has not been manually edited:
    try
        rmpath(handles.tbBFilePath.String);
    catch
    end
    if iNargin == 0
        set(handles.pbBTest, 'Enable', 'on');
    else
        set(handles.pbBTest, 'Enable', 'off');
    end
    % If we have previously tested, delete all the used uicontrols:
    if ~bFirstTime
        stBArgumentName = getappdata(hSoluCheck, 'stBArgumentName');
        tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
        pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
        tbBStepSize = getappdata(hSoluCheck, 'tbBStepSize');
        stBDivider = getappdata(hSoluCheck, 'stBDivider');
        if ~isempty(stBArgumentName)
            for i = 1:length(stBArgumentName)
                delete(stBArgumentName{i});
                delete(tbBArgument{i});
                delete(pmBDataType{i});
                delete(tbBStepSize{i});
                delete(stBDivider{i});
            end
            setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0, (33 .* i), 0, 0]);
            setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0, (33 .* i), 0, 0]);
        end
    end
    % tells SoluCheck this is not first time any more!
    bFirstTime = false;
    % update the UI with complete information:
    setappdata(handles.uiBSoluCheck, 'bFirstTime', bFirstTime);
    set(handles.stBArgumentNumber, 'string', num2str(iNargin));
    % Create starting cell arrays:
    stBArgumentName = cell(1, iNargin);
    tbBArgument = cell(1, iNargin);
    pmBDataType = cell(1, iNargin);
    tbBStepSize = cell(1, iNargin);
    stBDivider = cell(1, iNargin);
    % Create the UI Controls:
    for i = 0:iNargin-1
        %Set the handles for arg names
        stBArgumentName{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['stBArgumentName' num2str(i+1)], 'Style', 'text', 'String', sprintf('Argument %d:', i+1), 'FontSize', 10.0);
        setpixelposition(stBArgumentName{i+1}, getpixelposition(handles.stBArgumentNameExample) + [0, (-33 .* i), 0, 0]);
        %Set handles for arguments
        tbBArgument{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['tbBArgument' num2str(i+1)], 'Style', 'edit', 'HorizontalAlignment', 'left', 'FontSize', 10.0, 'String', '', ...
            'ButtonDownFcn', @tbBArgumentExample_ButtonDownFcn, 'KeyPressFcn', @tbBArgument_KeyPressFcn);
        setpixelposition(tbBArgument{i+1}, getpixelposition(handles.tbBArgumentExample) + [0, (-33 .* i), 0, 0]);
        %Set handles for data types
        pmBDataType{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['pmBDataType' num2str(i+1)], 'Style', 'popupmenu', 'String', {'Select A Data Type:', 'Predefined Variable...', 'String', 'Number', 'Array',...
            'Cell Array','Logical', 'Formulaic...'}, 'FontSize', 10.0, 'Callback', @pmBData_Callback, 'Value', 1);
        setpixelposition(pmBDataType{i+1}, getpixelposition(handles.pmBDataTypeExample) + [0, (-33 .* i), 0, 0]);     
        %Set handles for the step sizes
        tbBStepSize{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['tbBStepSize' num2str(i+1)], 'Style', 'edit', 'String', '1', 'HorizontalAlignment', 'left', 'FontSize', 10.0, ...
            'String', '1', 'KeyPressFcn', @tbBStepSize_KeyPressFcn);
        setpixelposition(tbBStepSize{i+1}, getpixelposition(handles.tbBStepExample) + [0, (-33 .* i), 0, 0]);
        %Set handles for the dividers
        stBDivider{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['stBDivider' num2str(i+1)], 'Style', 'text', 'HorizontalAlignment', 'left', 'string', get(handles.stBDividerExample, 'string'), 'FontSize', 4);
        setpixelposition(stBDivider{i+1}, getpixelposition(handles.stBDividerExample) + [0, (-33.*i), 0, 0]);
        %Move the two buttons
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0, -33, 0, 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0, -33, 0, 0]);
        %adjust the tab order
        uistack(handles.pbBAdvancedOptions, 'bottom');
        uistack(handles.pbBTest, 'bottom');
        uistack(handles.pbBCancel, 'bottom');
    end
    setappdata(hSoluCheck, 'stBArgumentName', stBArgumentName);
    setappdata(hSoluCheck, 'tbBArgument', tbBArgument);
    setappdata(hSoluCheck, 'pmBDataType', pmBDataType);
    setappdata(hSoluCheck, 'tbBStepSize', tbBStepSize);
    setappdata(hSoluCheck, 'stBDivider', stBDivider);
    % Tell the user that SoluCheck has been prepped and is awaiting
    % User Orders:
    strResult = sprintf('>> Loading File %s...Loaded!', sFileName);
    set(handles.stBTestResults, 'String', 'You''ve selected a valid file; now click Test to continue, or Advanced Options to customize your test.', 'ForegroundColor', 'black', 'BackgroundColor', 'white');
    if ~handles.cbBMute.Value
        sound(stcSounds(1).Start{:});
    end
    cellFormulaic = cell(1, iNargin);
    setappdata(findobj('Tag', 'uiBSoluCheck'), 'cellFormulaic', cellFormulaic);
elseif strcmp(get(handles.tbBFilePath, 'String'), 'Select your file...')
    % If the user cancelled, if we had not ever selected a file, then
    % don't mess with the test results! This might not be necessary.
    strResult = '>> Loading File...Cancelled!';
    set(handles.stBTestResults, 'String', 'Test Results');
else
    return
end

% Get the position of the testing button, so that we can determine how
% our scroller should respond:
vecPosn = getpixelposition(handles.pbBTest);
vecPosn = vecPosn(2);
if vecPosn < 0
    set(handles.slBYScroller, 'Min', 0.00, 'Max', abs(vecPosn), 'Value', abs(vecPosn), 'Visible', 'on');
else
    set(handles.slBYScroller, 'Min', 1.0, 'Max', 1.0, 'Value', 0);
end
intScrollerValue = abs(vecPosn);
setappdata(hSoluCheck, 'intScrollerValue', intScrollerValue);
vecFirstPosn = getpixelposition(handles.pbBTest);
setappdata(hSoluCheck, 'vecFirstPosn', vecFirstPosn);

if stcSwitches.Details
    hViewer = findobj('Tag', 'uiVViewer');
    hViewer = hViewer.Children(3);
    strOld = get(hViewer, 'String');
    [intLines, ~] = size(strOld);
    cellViewer = cell(1, intLines + 1);
    for i = 1:intLines
        cellViewer{i} = strOld(i, :);
    end
    cellViewer(2:end) = cellViewer(1:end-1);
    cellViewer{1} = strResult;
    set(hViewer, 'String', strjoin(cellViewer, '\n'));
end

function pbBFilePath_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if any(strcmp({' ', 'return'}, eventdata.Key))
    pbBFilePath_Callback(hObject, [], handles);
end

function tbBArgument_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if strcmp('return', eventdata.Key) && strcmp(handles.pbBTest.Enable, 'on')
    pbBTest_Callback(handles.pbBTest, [], handles);
end

function tbBStepSize_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if strcmp('return', eventdata.Key) && strcmp(handles.pbBTest.Enable, 'on')
    pbBTest_Callback(handles.pbBTest, [], handles);
end

% --- Executes on button press in pbBSolutionFilePath.
function pbBSolutionFilePath_Callback(hObject, eventdata, handles)
% hObject    handle to pbBSolutionFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
stcSwitches = getappdata(findobj('Tag', 'uiBSoluCheck'), 'stcSwitches');
% only show p files!
[sSolutionName, sSolutionPath] = uigetfile('*.p');
if all(sSolutionPath == 0)
    set(handles.tbBSolutionPath, 'string', 'Select your solution file...');
else
    set(handles.tbBSolutionPath, 'string', [sSolutionPath sSolutionName]);
    setappdata(findobj('Tag', 'uiBSoluCheck'), 'sSolutionPath', sSolutionPath);
    setappdata(findobj('Tag', 'uiBSoluCheck'), 'sSolutionName', sSolutionName);
    addpath(sSolutionPath);
    strResult = 'Loading File %s...Loaded!';
end
if stcSwitches.Details
    hViewer = findobj('Tag', 'uiVViewer');
    hViewer = hViewer.Children(3);
    strOld = get(hViewer, 'String');
    [intLines, ~] = size(strOld);
    cellViewer = cell(1, intLines + 1);
    for i = 1:intLines
        cellViewer{i} = strOld(i, :);
    end
    cellViewer(2:end) = cellViewer(1:end-1);
    cellViewer{1} = strResult;
    set(hViewer, 'String', strjoin(cellViewer, '\n'));
end

function pbBSolutionFilePath_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if strcmp({' ', 'return'}, eventdata.Key)
    pbBSolutionPath_Callback(hObject, [], handles);
end

% --- Executes on button press in pbBAdvancedOptions.
function pbBAdvancedOptions_Callback(hObject, eventdata, handles)
% hObject    handle to pbBAdvancedOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AdvancedOptions;

function tbBIterations_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if strcmp(eventdata.Key, 'return') && strcmp(handles.pbBTest.Enable, 'on')
    pbBTest_Callback(handles.pbBTest, [], handles);
end

% --- Executes on button press in pbBCancel.
function pbBCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbBCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
    
% --- Executes on button press in pbBTest.
function pbBTest_Callback(hObject, eventdata, handles)
% hObject    handle to pbBTest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
iNargin = getappdata(hSoluCheck, 'iNargin');
sFileName = getappdata(hSoluCheck, 'sFileName');
sSolutionName = getappdata(hSoluCheck, 'sSolutionName');
stBArgumentName = getappdata(hSoluCheck, 'stBArgumentName');
tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
tbBStepSize = getappdata(hSoluCheck, 'tbBStepSize');
stBDivider = getappdata(hSoluCheck, 'stBDivider');
stcSounds = getappdata(findobj('Tag', 'uiBSoluCheck'), 'stcSounds');
set(handles.pbBCancel, 'String', 'Cancel');
bError = false;
set(handles.stBTestResults, 'String', 'Please Wait - Testing...', 'BackgroundColor', 'blue', 'ForegroundColor', 'white'); 
pause('on');
pause(1/1000);
pause('off');
stcSwitches = getappdata(handles.uiBSoluCheck, 'stcSwitches');
cstBArgumentName = cell(1, iNargin);
ctbBArgument = cell(1, iNargin);
cDataType = cell(1, iNargin);
ctbBStepSize = cell(1, iNargin);
cstBDivider = cell(1, iNargin);
cArgs = cell(1, iNargin .* 2);

%Data Types
%1. Select A Data Type:
%1. Predefined Variable...
%2. String
%3. Number
%4. Array
%5. Cell Array
%6. Logical
%7. Formulaic...
cClass = {'Predefined Variable...', 'String', 'Number', 'Array', 'Cell Array', 'Logical', 'Formulaic...'};

strError = '';
if stcSwitches.LoadDatabase
    for i = 1:iNargin
        ctbBArgument{i} = 1;
        ctbBStepSize{i} = 0;
        cArgs{2 .* i -1} = ctbBArgument{i};
        cArgs{2 .* i} = ctbBStepSize{i};
    end
else
    for i = 1:iNargin
        cstBArgumentName{i} = get(stBArgumentName{i}, 'string');
        ctbBArgument{i} = get(tbBArgument{i}, 'string');
        % Subtract 1, so that 1-7 is the data types; this will cause a 0
        % though!!!!
        cDataType{i} = get(pmBDataType{i}, 'value') - 1;
        switch cDataType{i}
            case 0
                % if it is 0, then the user done messed up. Return with
                % error and log to viewer, if possible:
                bError = true;
                strError = [strError sprintf('Argument #%d: The Data type must be defined!', i)]; %#ok<AGROW>
            case 1
                try
                    ctbBArgument{i} = evalin('base', char(ctbBArgument{i}));
                    if isempty(ctbBArgument{i})
                        bError = true;
                        strError = [strError sprintf('Argument #%d: The variable found resulted in a null value.\n', i)];   %#ok<AGROW>
                    end
                catch ME
                    bError = true;
                    if strcmp(ME.identifier, 'MATLAB:UndefinedFunction')
                        strError = [strError sprintf('Argument #%d: The variable is not currently defined.\n', i)];    %#ok<AGROW>
                    else
                        strError = [strError sprintf('Argument #%d: Evaluation failed.\n', i)];  %#ok<AGROW>
                    end
                    % I don't think this is really working to be honest.
                    %[~, sWarningID] = lastwarn;
                    %if strcmp(sWarningID, 'MATLAB:namelengthmaxexceeded')
                    %    sError = [sError sprintf('Argument #%d: the variable length is too long!\n', i)];         %#ok<AGROW>
                    %end
                end
            case 2
                try
                    ctbBArgument{i} = char(ctbBArgument{i});
                    if any(any(isnan(ctbBArgument{i})))
                        bError = true;
                        strError = [strError sprintf('Argument #%d: Conversion to class %s resulted in a null value.\n', i, cClass{2})];  %#ok<AGROW>
                    end
                catch %#ok<*CTCH>
                    bError = true;
                    strError = [strError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{2})];   %#ok<AGROW>
                end
            case 3
                try
                    ctbBArgument{i} = str2double(ctbBArgument{i});
                    if isempty(ctbBArgument{i}) || any(any(isnan(ctbBArgument{i})))
                        bError = true;
                        strError = [strError sprintf('Argument #%d: Conversion to class %s resulted in a null value.\n', i, cClass{3})];    %#ok<AGROW>
                    end
                catch
                    bError = true;
                    strError = [strError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{3})];  %#ok<AGROW>
                end
            case 4
                try
                    ctbBArgument{i} = evalin('base', ctbBArgument{i});
                    if isempty(ctbBArgument{i}) || any(any(isnan(ctbBArgument{i})))
                        bError = true;
                        strError = [strError sprintf('Argument #%d: Conversion to class %s resulted in a null value.\n', i, cClass{4})];    %#ok<AGROW>
                    end
                catch
                    bError = true;
                    strError = [strError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{4})];   %#ok<AGROW>
                end
            case 5
                try
                    ctbBArgument{i} = eval(ctbBArgument{i});
                    if ~iscell(ctbBArgument{i})
                        bError = true;
                        strError = [strError sprintf('Argument #%d: No cell array detected.\n', i)]; %#ok<AGROW>
                    else
                        strError = [strError sprintf('Argument #%d: A cell array was detected and was not stepped.\n', i)]; %#ok<AGROW>
                    end
                catch
                    bError = true;
                    strError = [strError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{5})];    %#ok<AGROW>
                end
            case 6
                try
                    ctbBArgument{i} = logical(evalin('base', ctbBArgument{i}));
                    if ~islogical(ctbBArgument{i})
                        bError = true;
                        strError = [strError sprintf('Argument #%d: No logical vector detected. Please enter it in the form of either [1 0 ...] or [true, false, ...]\n', i)];  %#ok<AGROW>
                    end
                catch
                    bError = true;
                    strError = [strError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{7})];      %#ok<AGROW>
                end
            case 7
                try
                    ctbBArgument{i} = 'Stored Formula';
                    strError = [strError sprintf('Argument #%d: A Formulaic Entry was detected and was not stepped.\n', i)];    %#ok<AGROW>
                catch ME
                    bError = true;
                    strError = [strError sprintf('Argument #%d: Unable to evaluate formula. Error Message:\n%s\n', i, ME.message)]; %#ok<AGROW>
                end
            otherwise
                bError = true;
                strError = [strError sprintf('Argument #%d: Undefined data type.\n', i)]; %#ok<AGROW>
        end

        ctbBStepSize{i} = get(tbBStepSize{i}, 'string');
        if strcmp(ctbBStepSize{i}, '0') || isempty(ctbBStepSize)
            ctbBStepSize{i} = 'N/A';
        else
            ctbBStepSize{i} = str2double(ctbBStepSize{i});
        end
        cstBDivider{i} = get(stBDivider{i}, 'string');
        cArgs{2 .* i -1} = ctbBArgument{i};
        cArgs{2 .* i} = ctbBStepSize{i};
    end
end
intIterations = str2double(handles.tbBIterations.String);
if intIterations == inf || intIterations <= 0
    bError = true;
    strError = [strError sprintf('Iteration Amount: Please enter a positive, finite entry!\n')];
end

if ~bError
    assignin('base', 'intIterationNumber', 0);
    [bPassed, sEngineError, intArgNumber, cFinalArgs, cAnswers, cSolutions, vecTime1, vecTime2] = ...
        SoluCheckEngine(sFileName(1:end-2),sSolutionName(1:end-2), round(intIterations), cDataType, cArgs{:});
    setappdata(hSoluCheck, 'cFinalArgs', cFinalArgs);
    setappdata(hSoluCheck, 'cAnswers', cAnswers);
    setappdata(hSoluCheck, 'cSolutions', cSolutions);
    if intArgNumber == 1
        sArgNumber = '1 iteration';
    else
        sArgNumber = sprintf('%d iterations', intArgNumber);
    end
    
    if stcSwitches.PlotTesting
        vecPercents = getappdata(handles.uiBSoluCheck, 'vecPlotAverage');
        
        strError = [strError sprintf('Average Plot Difference: %0.4f%%', (mean(vecPercents) / numel(vecPercents)) * 100)];
    end
    if bPassed
        strResult = sprintf(['We have successfully tested your function. Using %s, we found no disagreements between your function and the given solution file.\nTest Passed!'...
            '\nAlerts Generated:\n%s'], sArgNumber, strError);
        set(handles.stBTestResults, 'string', strResult, 'BackgroundColor', 'Green', 'ForegroundColor', 'black');
        if ~handles.cbBMute.Value
            intChoice = randi([1, 4]);
            sound(stcSounds(intChoice).Pass{:});
        end
    elseif isempty(sEngineError)
        strResult = sprintf(['We have successfully tested your function, and we found a disagreement. The iteration number was %d, and the arguments used for this iteration, '...
            'as well as your answers and the solutions, have been output to the command line.\nTest Failed!\nAlerts Generated:\n%s'], intArgNumber, strError);
        set(handles.stBTestResults, 'string', strResult, 'BackgroundColor', 'Red', 'ForegroundColor', 'white');
        if ~handles.cbBMute.Value
            intChoice = randi([1, 3]);
            sound(stcSounds(intChoice).Fail{:});
        end
    else
        strResult = sprintf('We were unsuccessful in testing the functions; Here''s the error message that was last produced:\n%s\nTest Error!', sEngineError);
        set(handles.stBTestResults, 'string', strResult, 'BackgroundColor', 'Yellow', 'ForegroundColor', 'black');
        if ~handles.cbBMute.Value
            intChoice = randi([1, 3]);
            sound(stcSounds(intChoice).Error{:});
        end
    end
    
    pause('on');
    pause(1/10000);
    pause('off');
    
    assignin('base', 'cArguments', cFinalArgs);
    assignin('base', 'cAnswers', cAnswers);
    assignin('base', 'cSolutions', cSolutions);
    assignin('base', 'vecCodeTime', vecTime1);
    assignin('base', 'vecSolnTime', vecTime2);
    
    if stcSwitches.Timing
        uiPPlots = figure('Tag', 'uiPPlots', 'ToolBar', 'none', 'MenuBar', 'None', 'Name', 'SoluCheck Code Analyzer', 'NumberTitle', 'off');
        plot(1:intArgNumber, vecTime1, 1:intArgNumber, vecTime2);
        legend(sprintf('Code Time, Average of %ds', mean(vecTime1)), sprintf('Solution Time, Average of %ds', mean(vecTime2)));
        title(sprintf('SoluCheck Code Analyzer: %s', sFileName));
        xlabel('Number of Iterations');
        ylabel('Time to compute, in seconds');
        pbPSave = uicontrol(uiPPlots, 'Style', 'pushbutton', 'String', 'Save', 'Callback', @pbPSave_Callback, 'FontSize', 10.0, 'HorizontalAlignment', 'center', 'Units', 'Normalized');
        uiPPlotsPosn = getpixelposition(uiPPlots);
        setpixelposition(pbPSave, [uiPPlotsPosn(3) - 40, 0, 40, 30]);
    end
    
    if stcSwitches.Profiler
        profile('viewer');
    end
else
    strResult = sprintf('There were one or more errors in your arguments. Please try again. Details:\n%s', strError);
    set(handles.stBTestResults, 'string', strResult, 'BackgroundColor', 'Yellow', 'ForegroundColor', 'black');
    if ~handles.cbBMute.Value
        intChoice = randi([1, 3]);
        sound(stcSounds(intChoice).Error{:})
    end
end
if stcSwitches.Notifications
    cOldPrf = getappdata(handles.uiBSoluCheck, 'cOldPrf');
    cNewPrf = getappdata(handles.uiBSoluCheck, 'cNewPrf');
    if bPassed
        strResult = sprintf('Passed!\nDetails:\n\n%s', strResult);
    elseif bError
        strResult = sprintf('Errored Out!\nDetails:\n\n%s', strResult);
    else
        strResult = sprintf('Failed!\nDetails:\n\n%s', strResult);
    end
    try
        if cNewPrf{4}
            save('results.mat', 'cFinalArgs', 'cAnswers', 'cSolutions', 'vecTime1', 'vecTime2');
            sendmail(cNewPrf{3}, 'SoluCheck Complete!', sprintf('Dear %s,\n\nSoluCheck has finished testing your code. Your code %s\n\nThe SoluWorks Team', [cNewPrf{1} ' ' cNewPrf{2}], strResult), 'results.mat');
            prfRecycleState = recycle;
            recycle('on');
            delete('results.mat');
            recycle(prfRecycleState);
        else
            sendmail(cNewPrf{3}, 'SoluCheck Complete!', sprintf('Dear %s,\n\nSoluCheck has finished testing your code. Your code %s\n\nThe SoluWorks Team', [cNewPrf{1} ' ' cNewPrf{2}], strResult));
        end
    catch ME
        msgbox(sprintf('Notification Failed!\n\nError:\n%s\n%s', ME.identifier, ME.message))
    end
    try
        setpref('Internet', 'SMTP_Server', cOldPrf{1});
        setpref('Internet','E_mail', cOldPrf{2});
        setpref('Internet','SMTP_Username', cOldPrf{2});
        setpref('Internet','SMTP_Password', cOldPrf{3});
        props = java.lang.System.getProperties;
        props.setProperty('mail.smtp.auth', cOldPrf{4});
        props.setProperty('mail.smtp.socketFactory.class', cOldPrf{5});
        props.setProperty('mail.smtp.socketFactory.port',cOldPrf{6});
    catch
        msgbox('Your message was sent, but we ran into problems reverting back to the old settings.', 'SoluCheck Notifications');
    end
end
if stcSwitches.Details
    hViewer = findobj('Tag', 'uiVViewer');
    hViewer = hViewer.Children(3);
    strOld = get(hViewer, 'String');
    [intLines, ~] = size(strOld);
    cellViewer = cell(1, intLines + 1);
    for i = 1:intLines
        cellViewer{i} = strOld(i, :);
    end
    cellViewer(2:end) = cellViewer(1:end-1);
    cellViewer{1} = strResult;
    set(hViewer, 'String', strjoin(cellViewer, '\n'));
end
set(handles.pbBCancel, 'String', 'Done');

function pbBTest_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if any(strcmp({' ', 'return'}, eventdata.Key)) && strcmp(handles.pbBTest.Enable, 'on')
    pbBTest_Callback(handles.pbBTest, [], handles);
end

function pbBCancel_KeyPressFcn(hObject, eventdata, handles)
handles = guidata(hObject);
if any(strcmp({' ', 'return'}, eventdata.Key))
    pbBCancel_Callback(handles.pbBCancel, [], handles);
end

function pbPSave_Callback(hObject, callbackdata)
[strName, strPath] = uiputfile({'*.jpg'}, 'Save As:', 'CodeAnalyzer.jpg');
strFileName = [strPath, strName];
if strName ~= 0;
    saveas(hObject.Parent, strFileName);
end 
    
function tbBIterations_Callback(hObject, eventdata, handles)
% hObject    handle to tbBIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBIterations as text
%        str2double(get(hObject,'String')) returns contents of tbBIterations as a double


% --- Executes during object creation, after setting all properties.
function tbBIterations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tbBArgumentExample_Callback(hObject, eventdata, handles)
% hObject    handle to tbBArgumentExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBArgumentExample as text
%        str2double(get(hObject,'String')) returns contents of tbBArgumentExample as a double


% --- Executes during object creation, after setting all properties.
function tbBArgumentExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBArgumentExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tbBArgumentExample_ButtonDownFcn(hObject, eventdata, handles)
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
strName = hObject.Tag;
intArgument = str2double(strName(12:end));
if ~strcmp(hObject.Enable, 'on')
    if pmBDataType{intArgument}.Value == 8
        cellFormulaic = getappdata(findobj('Tag', 'uiBSoluCheck'), 'cellFormulaic'); 
        uiCCommandWindow = figure('Visible', 'off', 'Name', ['SoluCheck: Formulaic Entry #', strName(12:end)] , 'NumberTitle', 'off', 'position', [350 50 500 550], 'Tag', 'uiCCommandWindow');
        tbCCommandLine = uicontrol('Style', 'edit', 'position', [0, 50, 500, 500], 'HorizontalAlignment', 'left', 'Max', 100, 'Min', 0, 'Units', 'Normalized', 'String', '>> ', 'FontSize', 10.0, 'ToolTip', sprintf(['Please enter your code in the following field as it would be entered into the command line.\n**Assign the desired argument value to the out variable!\n'... 
                        'Note that you may utilize the current iteration by calling the variable intIterationNumber']));
        pbCConfirm = uicontrol('Style', 'pushbutton', 'string', 'Confirm', 'position', [250, 0, 250, 50], 'Callback', {@pbCConfirm_Callback, hObject.Tag}, 'Units', 'Normalized'); %#ok<NASGU>
        pbCCancel = uicontrol('Style', 'pushbutton', 'String', 'Cancel', 'position', [0, 0, 250, 50], 'Callback', {@pbCEditCancel_Callback, hObject.Tag}, 'Units', 'Normalized'); %#ok<NASGU>
        uiCCommandWindow.Visible = 'on';
        cellFormulaic{intArgument}{1} = ['>> ' cellFormulaic{intArgument}{1}];
        tbCCommandLine.String = strjoin(cellFormulaic{intArgument}, '\n');
        setappdata(hSoluCheck, 'tbCCommandLine', tbCCommandLine);
    elseif pmBDataType{intArgument}.Value == 2
        cellVariables = evalin('base', 'who');
        uiWWorkSpace = figure('Visible', 'off', 'Name', ['SoluCheck: WorkSpace Variable #', strName(12:end)], 'NumberTitle', 'off', 'position', [350 50 500 450], 'Tag', 'uiWWorkSpace', 'Units', 'Normalized');
        lbWVariables = uicontrol('Style', 'listbox', 'Tag', 'lbWVariables', 'String', cellVariables, 'FontSize', 10.0, 'Callback', {@lbWVariables_Callback, hObject.Tag});
        vecPosn = getpixelposition(uiWWorkSpace);
        vecPosn(1:2) = 0;
        setpixelposition(lbWVariables, vecPosn);
        uiWWorkSpace.Visible = 'on';
        set(tbBArgument{intArgument}, 'Enable', 'off');
    end
end

function pbCEditCancel_Callback(hObject, callbackdata, strName)
close;

function tbBStepExample_Callback(hObject, eventdata, handles)
% hObject    handle to tbBStepExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBStepExample as text
%        str2double(get(hObject,'String')) returns contents of tbBStepExample as a double


% --- Executes during object creation, after setting all properties.
function tbBStepExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBStepExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in pmBDataTypeExample.
function pmBDataTypeExample_Callback(hObject, eventdata, handles)
% hObject    handle to pmBDataTypeExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmBDataTypeExample contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmBDataTypeExample


% --- Executes during object creation, after setting all properties.
function pmBDataTypeExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmBDataTypeExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

set(hObject, 'string', {'DataTypeExample', 'String', 'Number', 'Array', 'Cell Array', 'Custom...'});
    
function pmBData_Callback(hObject, callbackdata)
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
hpbBTest = findobj('Tag', 'pbBTest');
tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
tbBStepSize = getappdata(hSoluCheck, 'tbBStepSize');
strName = hObject.Tag;
intName = str2double(strName(12:end));
iNargin = getappdata(hSoluCheck, 'iNargin');
if hObject.Value == 8
    uiCCommandWindow = figure('Visible', 'off', 'Name', ['SoluCheck: Formulaic Entry #', strName(12:end)], 'NumberTitle', 'off', 'position', [350 50 500 550], 'Tag', 'uiCCommandWindow');
    tbCCommandLine = uicontrol('Style', 'edit', 'position', [0, 50, 500, 500], 'HorizontalAlignment', 'left', 'Max', 100, 'Min', 0, 'Units', 'Normalized', 'String', '>> ', 'FontSize', 10.0, 'ToolTip',...
        sprintf(['Please enter your code in the following field as it would be entered into the command line.\n**Assign the desired argument value to the out variable!\n'... 
                        'Note that you may utilize the current iteration by calling the variable intIterationNumber.']));
    pbCConfirm = uicontrol('Style', 'pushbutton', 'string', 'Confirm', 'position', [250, 0, 250, 50], 'Callback', {@pbCConfirm_Callback, hObject.Tag}, 'Units', 'Normalized'); %#ok<NASGU>
    pbCCancel = uicontrol('Style', 'pushbutton', 'String', 'Cancel', 'position', [0, 0, 250, 50], 'Callback', {@pbCCancel_Callback, hObject.Tag}, 'Units', 'Normalized'); %#ok<NASGU>
    uiCCommandWindow.Visible = 'on';
    set(tbBArgument{intName}, 'Enable', 'inactive');
    setappdata(hSoluCheck, 'tbCCommandLine', tbCCommandLine);
elseif hObject.Value == 2
    cellVariables = evalin('base', 'who');
    uiWWorkSpace = figure('Visible', 'off', 'Name', ['SoluCheck: WorkSpace Variable #', strName(12:end)], 'NumberTitle', 'off', 'position', [350 50 500 450], 'Tag', 'uiWWorkSpace', 'Units', 'Normalized');
    lbWVariables = uicontrol('Style', 'listbox', 'Tag', 'lbWVariables', 'String', cellVariables, 'FontSize', 10.0, 'Callback', {@lbWVariables_Callback, hObject.Tag});
    vecPosn = getpixelposition(uiWWorkSpace);
    vecPosn(1:2) = 0;
    setpixelposition(lbWVariables, vecPosn);
    uiWWorkSpace.Visible = 'on';
    set(tbBArgument{intName}, 'Enable', 'off');
else
    set(tbBArgument{intName}, 'Enable', 'on');
end

switch hObject.Value
    case {1, 2, 6, 8}
        set(tbBStepSize{intName}, 'Enable', 'off', 'string', '')
    case {3, 4, 5, 7}
        set(tbBStepSize{intName}, 'Enable', 'on');
end
set(hpbBTest, 'Enable', 'on');
for i = 1:iNargin
    intChoice = pmBDataType{i}.Value;
    if intChoice == 1
        set(hpbBTest, 'Enable', 'off');
    break
    end
end

function pbCConfirm_Callback(hObject, callbackdata, strName)
tbBArgument = getappdata(findobj('Tag', 'uiBSoluCheck'), 'tbBArgument');
tbCCommandLine = getappdata(findobj('Tag', 'uiBSoluCheck'), 'tbCCommandLine');
cellFormulaic = getappdata(findobj('Tag', 'uiBSoluCheck'), 'cellFormulaic');
strCode = tbCCommandLine.String;
[strFirst, strSecond] = strtok(strCode(1, :), '> ');
[intLines, ~] = size(strCode);
cellCode = cell(1, intLines);
cellCode{1} = [strFirst strSecond];
for i = 2:intLines
    cellCode{i} = strCode(i, :);
end
intArgument = str2double(strName(12:end));
cellFormulaic{intArgument} = cellCode;
% what if we instead STORE the code in the app? Then it could be evaluated
% every time!!!!
% To do this, we would need to have standardized method for storing data!
% We would also need to open the engine, but we will deal with that later.
% Our naming method: 
% strResult = evalc(strjoin(cellCode, '\n'));
% [~, strResult] = strtok(strResult, '=');
% [~, strResult] = strtok(strResult, ' =');
% strResult = strtok(strResult);
setappdata(findobj('Tag', 'uiBSoluCheck'), 'cellFormulaic', cellFormulaic);
set(tbBArgument{intArgument}, 'String', 'Stored Formula:');
close;

function pbCCancel_Callback(hObject, callbackdata, strName)
pmBDataType = getappdata(findobj('Tag', 'uiBSoluCheck'), 'pmBDataType');
hPopMenu = pmBDataType{str2double(strName(12:end))};
hPopMenu.Value = 1;
close;

function lbWVariables_Callback(hObject, callbackdata, strName)
tbBArgument = getappdata(findobj('Tag', 'uiBSoluCheck'), 'tbBArgument');
intChoice = hObject.Value;
cellChoices = hObject.String;
tbBArgument{str2double(strName(12:end))}.String = cellChoices{intChoice};
setappdata(findobj('Tag', 'uiBSoluCheck'), 'tbBArgument', tbBArgument);
close;

% --- Executes when uiBSoluCheck is resized.
function uiBSoluCheck_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to uiBSoluCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

vecOldSize = getappdata(findobj('Tag', 'uiBSoluCheck'), 'vecOldSize');
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
iNargin = getappdata(hSoluCheck, 'iNargin');
stBArgumentName = getappdata(hSoluCheck, 'stBArgumentName');
tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
tbBStepSize = getappdata(hSoluCheck, 'tbBStepSize');
stBDivider = getappdata(hSoluCheck, 'stBDivider');
bFirstTime = getappdata(findobj('Tag', 'uiBSoluCheck'), 'bFirstTime');
vecPosition = getpixelposition(hObject);
vecNewSize = vecPosition(3:4);
vecDifference = [0, (vecNewSize(2)-vecOldSize(2)), 0, 0];
celNames = fieldnames(handles)';
celFields = {stBArgumentName, tbBArgument, pmBDataType, tbBStepSize, stBDivider};
for i = 2:length(celNames)-1
    if ~any(strcmp(celNames{i}, {'pbBAdvancedOptions', 'pbBHelp', 'cbBMute'}))
        k = findobj('Tag', celNames{i});
        setpixelposition(k, getpixelposition(k) + vecDifference);
    end
end
if ~bFirstTime
    for i = 1:length(celFields)
        for j = 1:iNargin
            k = celFields{i}{j};
            setpixelposition(k, getpixelposition(k) + vecDifference);
        end
    end
end

vecSliderPosn = getpixelposition(handles.slBYScroller);
vecTopPosn = getpixelposition(handles.stBTop);
vecNewPosn = [vecSliderPosn(1), 0, vecSliderPosn(3), vecTopPosn(2)];
setpixelposition(handles.slBYScroller, vecNewPosn);
vecTestButtonPosn = getpixelposition(handles.pbBTest);

if vecTestButtonPosn(2) >= 0
    set(handles.slBYScroller, 'Visible', 'off');
    
    if (get(handles.slBYScroller, 'Value') ~= get(handles.slBYScroller, 'Max')) && ~bFirstTime
        % Code that moves everything back up. We know the value of max, and
        % we know the value. so, we should act like we are moving
        % everything back up, right? To do this, we should move everything
        % by the value of our scroller, right?
        intDifference = get(handles.slBYScroller, 'Value') - get(handles.slBYScroller, 'Max');
        for i = 1:length(celFields)
            for j = 1:iNargin
                k = celFields{i}{j};
                setpixelposition(k, getpixelposition(k) + [0 intDifference 0 0]);
                k.Visible = 'on';
            end
        end
        handles.slBYScroller.Value = handles.slBYScroller.Max;
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0 intDifference 0 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0 intDifference 0 0]);
    end
else
    intScrollerValue = abs(vecTestButtonPosn(2));
    setappdata(hSoluCheck, 'intScrollerValue', intScrollerValue);
    set(handles.slBYScroller, 'Visible', 'on', 'Max', abs(vecTestButtonPosn(2)), 'Value', abs(vecTestButtonPosn(2)));
end
% 
% if vecTestButtonPosn(2) >= 0
%     set(handles.slBYScroller, 'Max', 1.0, 'Min', 1.0, 'Value', 0.0);
% else
%     set(handles.slBYScroller, 'Min', 0.00, 'Max', abs(vecTestButtonPosn(2)), 'Value', abs(vecTestButtonPosn(2)));
%     intScrollerValue = abs(vecTestButtonPosn(2));
% end
vecOldSize = vecNewSize;
setappdata(findobj('Tag', 'uiBSoluCheck'), 'vecOldSize', vecOldSize);


% --- Executes on slider movement.
function slBYScroller_Callback(hObject, eventdata, handles)
% hObject    handle to slBYScroller (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

hSoluCheck = findobj('Tag', 'uiBSoluCheck');
iNargin = getappdata(hSoluCheck, 'iNargin');
intScrollerValue = getappdata(hSoluCheck, 'intScrollerValue');
stBArgumentName = getappdata(hSoluCheck, 'stBArgumentName');
tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
tbBStepSize = getappdata(hSoluCheck, 'tbBStepSize');
stBDivider = getappdata(hSoluCheck, 'stBDivider');
bFirstTime = getappdata(findobj('Tag', 'uiBSoluCheck'), 'bFirstTime');
if isempty(intScrollerValue)
    intScrollerValue = get(hObject, 'Max');
end
intTop = getpixelposition(handles.stBTop);
celNames = {stBArgumentName, tbBArgument, pmBDataType, tbBStepSize, stBDivider};
intDifference = -(get(hObject, 'Value') - intScrollerValue);
if ~bFirstTime
    for i = 1:length(celNames)
        for j = 1:iNargin
            k = celNames{i}{j};
            setpixelposition(k, getpixelposition(k) + [0 intDifference 0 0]);
            intPosn = getpixelposition(k);
            if intPosn(2) + intPosn(4) >= intTop(2)
                set(k, 'Visible', 'off');
            else
                set(k, 'Visible', 'on');
            end
        end
    end
setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0 intDifference 0 0]);
setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0 intDifference 0 0]);
end

intScrollerValue = get(hObject, 'Value');
setappdata(hSoluCheck, 'intScrollerValue', intScrollerValue);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slBYScroller_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slBYScroller (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on scroll wheel click while the figure is in focus.
function uiBSoluCheck_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to uiBSoluCheck (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)
bFirstTime = getappdata(findobj('Tag', 'uiBSoluCheck'), 'bFirstTime');
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
iNargin = getappdata(hSoluCheck, 'iNargin');
stBArgumentName = getappdata(hSoluCheck, 'stBArgumentName');
tbBArgument = getappdata(hSoluCheck, 'tbBAgument');
pmBDataType = getappdata(hSoluCheck, 'pmBDataType');
tbBStepSize = getappdata(hSoluCheck, 'tbBStepSize');
stBDivider = getappdata(hSoluCheck, 'stBDivider');
vecFirstPosn = getappdata(hSoluCheck, 'vecFirstPosn');
if isempty(vecFirstPosn)
    vecFirstPosn = getpixelposition(handles.pbBTest);
    setappdata(hSoluCheck, 'vecFirstPosn', vecFirstPosn);
end
vecChange = [0 ((eventdata.VerticalScrollCount ./ abs(eventdata.VerticalScrollCount) .* eventdata.VerticalScrollAmount)) 0 0];

vecPosn = getpixelposition(handles.pbBTest);

if (vecPosn(2) + vecChange(2) <= vecFirstPosn(2)) && (vecChange(2) < 0)
    return
end

if vecPosn(2) + vecChange(2) >= 0
    vecChange = [0 vecPosn(2) 0 0];
end
celFields = {stBArgumentName, tbBArgument, pmBDataType, tbBStepSize, stBDivider};

if ~bFirstTime && vecPosn(2) < 0
    %Don't scroll if the y posn is not less than 0!!
    %Also, if we WOULD scroll past the end, we need to just go to the end;
    %not pass it!!!!
    % We need to find the distance to the end (pbBTest = 0), then apply
    % this to the given formula
    for i = 1:length(celFields)
        for j = 1:iNargin
            k = celFields{i}{j};
            setpixelposition(k, getpixelposition(k) + vecChange);
            vecKPosition = getpixelposition(k);
            vecTopPosition = getpixelposition(handles.stBTop);
            if vecKPosition(2) + vecKPosition(4) >= vecTopPosition(2)
                set(k, 'Visible', 'off');
            else
                set(k, 'Visible', 'on');
            end
        end
    end
    setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + vecChange);
    setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + vecChange);
    vecPosn = getpixelposition(handles.pbBTest);
    intScrollerValue = get(handles.slBYScroller, 'Value');
    set(handles.slBYScroller, 'Value', abs(vecPosn(2)));
    setappdata(hSoluCheck, 'intScrollerValue', intScrollerValue);
end

% --- Executes on button press in cbBMute.
function cbBMute_Callback(hObject, eventdata, handles)
% hObject    handle to cbBMute (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cbBMute


% --- Executes on button press in pbBHelp.
function pbBHelp_Callback(hObject, eventdata, handles)
% hObject    handle to pbBHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fihHelp = figure('Visible', 'off', 'Name', 'SoluCheck: Help', 'Resize', 'off', 'NumberTitle', 'off', 'position', [350 50 450 400], 'Tag', 'uiHHelp');
tbHHelp = uicontrol('Style', 'edit', 'Enable', 'inactive', 'Tag', 'tbHHelp', 'Max', 100, 'Min', 0, 'FontSize', 10.0, 'HorizontalAlignment', 'left');
vecPosn = getpixelposition(fihHelp);
vecPosn = [0 50 vecPosn(3) vecPosn(4) - 50];
setpixelposition(tbHHelp, vecPosn);
cellHelp = {'Hi, welcome to the SoluCheck in-app Documentation!', ...
            'Here you will find answers to most common questions. When in doubt,',...
            'refer to the standalone documentation that came with SoluCheck.', ...
            '', ...
            'I. How do I get started?', ...
            '    First select a file to test using the ''Browse...'' button,', ...
            'Then, the solution file path will be autofilled, and you can now fill', ...
            'in your values. Fill in a value, then select the data type, then ', ...
            'select a step size. Please be advised that cell arrays and structures', ...
            'can NOT be stepped at this time.', 'Then, hit the test button, and enjoy!'...
            '', ...
            'II. What are Advanced Options?', ...
            '    Advanced Options give you much greater control over how SoluCheck', ...
            'attempts to test your code. For example, using Advanced Options, one', ...
            'can step array sizes, view details of multiple runs, set up notifications,', ...
            'Or load database tests. This is not a comprehensive list, but to use', ...
            'Advanced Options, look at the standalone Documentation or run the', ...
            'Help command on AdvancedOptions.', ...
            '', ...
            'III. How do I report possible bugs?', ...
            '    To report a bug, simply write an email to SoluCheck@gmail.com,', ...
            'and explain exactly what caused SoluCheck to crash. If you received', ...
            'an error message, please include that and any other media that you deem', ...
            'helpful. Please send bug reports! We can only', ...
            'solve a problem if we know it exists!', ...
            '', ...
            'Thanks for reading, and have fun!', ...
            'The SoluCheck Team'  };
strHelp = strjoin(cellHelp, '\n');
tbHHelp.String = strHelp;
pbHDocumentation = uicontrol('Style', 'pushbutton', 'FontSize', 10.0, 'String', 'Open Documentation...', 'Callback', @pbHDocumentation_Callback, 'HorizontalAlignment', 'center');
setpixelposition(pbHDocumentation, [0 0 vecPosn(3) 50]);
fihHelp.Visible = 'on';

function pbHDocumentation_Callback(hObject, eventdata, handles)

% Basically, it should be in the same folder that our app is in; how do we
% get this folder?
% get this by using matlab.apputil.getInstalledAppInfo, find the one called
% SoluCheck, then that's it!
stcAppInfo = matlab.apputil.getInstalledAppInfo;
for i = 1:numel(stcAppInfo)
    if strcmp(stcAppInfo(i).name, 'SoluCheck')
        strFolder = stcAppInfo(i).location;
        break
    end
end
strFile = [strFolder '\Media\Documentation.docx'];
try
    objWord = actxserver('Word.Application');
    objDocumentation = invoke(objWord.Documents, 'Open', strFile); %#ok<NASGU>
    objWord.Visible = 1;
catch ME
    msgbox('We were unable to launch MS Word; we cannot load the documentation!',...
        'SoluCheck Documentation');
    if stcSwitches.Details
        hViewer = findobj('Tag', 'uiVViewer');
        hViewer = hViewer.Children(3);
        strOld = get(hViewer, 'String');
        [intLines, ~] = size(strOld);
        cellViewer = cell(1, intLines + 2);
        for i = 1:intLines
            cellViewer{i} = strOld(i, :);
        end
        cellViewer(3:end) = cellViewer(1:end-1);
        cellViewer{2} = ME.identifier;
        cellViewer{1} = 'Word was not opened. Documentation Failed!';
        set(hViewer, 'String', strjoin(cellViewer, '\n'));
    end
end
% --- Executes when user attempts to close uiBSoluCheck.
function uiBSoluCheck_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to uiBSoluCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% should we get rid of any files that we used (ie, paths!?)
sFilePath = getappdata(findobj('Tag', 'uiBSoluCheck'), 'sFilePath');
strOldDir = getappdata(findobj('Tag', 'uiBSoluCheck'), 'strOldDir');
try
    if ~isempty(sFilePath)
        rmpath(sFilePath);
    end
catch
end

cFigures = {'uiAAdvancedOptions', 'uiFViewArguments', 'uiPPlots', 'uiEExempt',...
    'uiDLoadDatabase', 'uiLLoadVariables', 'uiNNotifications', 'uiRMaxMin', ...
    'uiSArrSize', 'uiVViewer', 'uiHHelp', 'uiWWorkSpace', 'uiPParameters'};

for i = 1:numel(cFigures)
    if ~isempty(findobj('Tag', cFigures{i}))
        delete(findobj('Tag', cFigures{i}));
    end
end
cd(strOldDir);
delete(hObject);