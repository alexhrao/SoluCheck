function [bolPassed, strError, intIterationNumber, cellArgs, cellAnswers, cellSolutions, vecCodeTime, vecSolnTime] = SoluCheckEngine(strFName, strFSolnName, intIterations, cellDataType, varargin)
% SOLUCHECKENGINE Core of SoluCheck Platform
%
%       Normally only used within the SoluCheck User Interface, the SoluCheck
%       Engine can nevertheless be called directly from the command line.
%
%       Arguments:      
%               1. A string that has the function name (with .m).
%               2. A string that represents the Solution Name (with .p).
%               3. A whole number of iterations to be performed.
%               4. A cell array of the data types, from 1-6.
%               5. A variable input. Give your argument, then the step 
%                   size, in that order, for all arguments.
%
%       SoluCheck Engine will output: 
%               1. Boolean of passing status.
%               2. String that represents any errors.
%               3. Number of iterations done.
%               4. Cell array of arguments used.
%               5. Cell array of your answers.
%               6. Cell array of the solutions.
%               7. Vector with your code times.
%               8. Vector with the solution code time.
%
%       To use the SoluCheck Engine, you'll need to have somewhat advanced
%       knowledge of how MATLAB operates. It is recommended that you use the
%       SoluCheck GUI instead; Engine use is only for experienced
%       programmers. Additionally, any errors you instigate will cause the
%       SoluCheck Engine to crash violently, without saving any results.
%
%       For more information, see the SoluCheck Documentation.
%   See also: SoluCheck, AdvancedOptions

% Initialize starting variables.
    strOldRecycle = recycle('off');
    strError = '';
    intIterationNumber = 0;
    hSoluCheck = findobj('Tag', 'uiBSoluCheck');
    stcAppInfo = matlab.apputil.getInstalledAppInfo;
    for m = 1:numel(stcAppInfo)
        if strcmp(stcAppInfo(m).name, 'SoluCheck')
            strFolder = stcAppInfo(m).location;
            break
        end
    end
    strCurrentPath = cd;
    addpath(strCurrentPath);
    cellTags = {'uiAAdvancedOptions', 'uiFViewArguments', 'uiPPlots', 'uiEExempt',...
    'uiDLoadDatabase', 'uiLLoadVariables', 'uiNNotifications', 'uiRMaxMin', ...
    'uiSArrSize', 'uiVViewer', 'uiHHelp', 'uiWWorkSpace', 'uiBSoluCheck', 'uiPParameters'};    
    % Check for the Switches; if it does not exist, create it!
    if isappdata(hSoluCheck, 'stcSwitches')
        stcSwitches = getappdata(hSoluCheck, 'stcSwitches');
        objProgressBar = getappdata(hSoluCheck, 'objProgressBar');
    else
        stcSwitches = struct('Profiler', false, ...
                             'Timing', false, ...
                             'LoadDatabase', false, ...
                             'LoadVariables', false, ...
                             'Details', false, ...
                             'MaxMin', false, ...
                             'Exempt', false, ...
                             'ArrSize', false, ...
                             'Notifications', false, ...
                             'Arguments', false, ...
                             'PlotTesting', false, ...
                             'FileTesting', false, ...
                             'ImageTesting', false, ...
                             'VariableIn', false, ...
                             'VariableOut', false);
    end
    if stcSwitches.FileTesting || stcSwitches.ImageTesting
        cd(strFolder);
    end
    % Initialize the progress bar!
    objProgressBar.setValue(0);
    objProgressBar.setMinimum(1);
    objProgressBar.setMaximum(intIterations);
    objProgressBar.setString('0.00%');
    
    % if the details are enabled, then prepare to load results into it!
    if stcSwitches.Details
        fViewer = findobj('Tag', 'uiVViewer');
        hViewer = guidata(fViewer);
        cViewer = cell(intIterations, 1);
        strOld = get(hViewer.tbVViewBox, 'String');
        [intOldLines, ~] = size(strOld);
    end
    
    % turn the profiler on or off, as indicated:
    if stcSwitches.Profiler
        profile('on');
    else
        profile('off');
    end
    % IF there are max and mins, then get the acceptable ranges
    if stcSwitches.MaxMin
        cellRanges = getappdata(hSoluCheck, 'celRanges');
    end
    % If there are exempt values, then get the exempt and stand-in values
    if stcSwitches.Exempt
        cellExempt = getappdata(hSoluCheck, 'celExempt');
        cellStandIn = getappdata(hSoluCheck, 'celStandIn');
    end
    % If we are stepping the array size, then get what sizes we need:
    if stcSwitches.ArrSize
        cellArraySizes = getappdata(hSoluCheck, 'celArraySizes');
    end
    
    if stcSwitches.PlotTesting
        vecPlotAverage = zeros(1, intIterations) - 1;
    end
    % If we are reading from a database, then get those values:
    if stcSwitches.LoadDatabase
        % Get the raw data:
        cRaw = getappdata(hSoluCheck, 'cRaw');
        [intIterations, intArgsData] = size(cRaw);
        cTests = cRaw(:, 1:2:end);
        cTypes = cRaw(:, 2:2:end);
        % for this, we'll need a try catch loop * infinity!!!
        try
            for j = 1:intArgsData / 2
                for i = 1:intIterations
                    switch lower(cTypes{i, j})
                        case 'string'
                            switch class(cTests{i, j})
                                case 'double'
                                    cTests{i, j} = num2str(cTests{i, j});
                            end
                        case 'number'
                            switch class(cTests{i, j})
                                case 'string'
                                    cTests{i, j} = str2double(cTests{i, j});
                            end
                        case 'array'
                            switch class(cTests{i, j})
                                case 'string'
                                    cTests{i, j} = evalin('base', cTests{i, j});
                            end
                        case 'cell array'
                            switch class(cTests{i, j})
                                case 'string'
                                    cTests{i, j} = evalin('base', cTests{i, j});
                                case 'double'
                                    cTests{i, j} = cTests(i, j);
                            end
                        case 'logical'
                            switch class(cTests{i, j})
                                case {'string', 'double'}
                                    cTests{i, j} = logical(evalin('base', cTests{i, j}));
                            end
                    end
                end
            end
        catch ME
            strError = sprintf('Database conversion failed! Check case #%d, Input %d\n%s', i, j, ME.message);
            bolPassed = false;
            cellAnswers = cell(0, 0);
            cellSolutions = cell(0, 0);
            cellArgs = cell(0, 0);
            vecCodeTime = 0;
            vecSolnTime = 0;
            return
        end
    end
    cellFormulaic = getappdata(hSoluCheck, 'cellFormulaic');
    try
        cellAnswers = cell(1, nargout(strFName) + 2);
        cellSolutions = cell(1, nargout(strFSolnName) + 2);
        cellArgs = cell(1, nargin(strFName));
        cellSteps = cell(1, nargin(strFName));
    catch ME
        strError = sprintf('%s\n%s', ME.identifier, ME.message);
        bolPassed = false;
        cellAnswers = cell(0, 0);
        cellSolutions = cell(0, 0);
        cellArgs = cell(0, 0);
        vecCodeTime = 0;
        vecSolnTime = 0;
        return
    end
    
    bolPassed = true;
    if stcSwitches.LoadDatabase
        i = 1;
        while i <= intArgsData / 2
            cellArgs{i} = cTests{1, i};
            i = i + 1;
        end
    else
        i = 0;
        while i < length(varargin) / 2
            cellSteps{i+1} = varargin{2 .* (i + 1)};
            cellArgs{i+1} = varargin{2 .* i + 1};
            i = i + 1;
        end
    end
    for i = 1:numel(cellArgs)
        if cellDataType{i} == 7;
            [vararg, cellError] = customWorkSpace__SystemFunction(cellFormulaic{i});
            if cellError{1}
                cstrError = cellError{3};
                intErrorLines = numel(cstrError);
                bolPassed = false;
                if stcSwitches.Details
                    cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Formulaic Error!', intIterationNumber);
                    cellTemp = cell(1, intOldLines + intIterationNumber);
                    for j = 1:intOldLines
                        cellTemp{j} = strOld(j, :);
                    end
                    cellTemp(intIterationNumber+1:end) = cellTemp(1:intOldLines);
                    cellTemp(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                    cellViewer = cell(intErrorLines + intIterationNumber + intOldLines);
                    cellViewer(1:intErrorLines) = cstrError;
                    cellViewer((intErrorLines+1):end) = cellTemp;
                    set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                end
                break
            else
                cellArgs{i} = vararg;
            end
        elseif cellDataType{i} == 1
            % evaluate in custom workspace, with out equalling the
            % variable!
            tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
            [vararg, cellError] = customWorkSpace({['out = ' tbBArgument{i}.String, ';']});
            if cellError{1}
                cstrError = cellError{3};
                intErrorLines = numel(cstrError);
                bolPassed = false;
                if stcSwitches.Details
                    cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Formulaic Error!', intIterationNumber);
                    cellTemp = cell(1, intOldLines + intIterationNumber);
                    for j = 1:intOldLines
                        cellTemp{j} = strOld(j, :);
                    end
                    cellTemp(intIterationNumber+1:end) = cellTemp(1:intOldLines);
                    cellTemp(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                    cellViewer = cell(intErrorLines + intIterationNumber + intOldLines);
                    cellViewer(1:intErrorLines) = cstrError;
                    cellViewer((intErrorLines+1):end) = cellTemp;
                    set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                end
                break
            else
                cellArgs{i} = vararg;
            end
        end
    end
    
    celCounter = cellArgs;
    intArgs = length(cellArgs);
    vecCodeTime = zeros(1, intIterations);
    vecSolnTime = zeros(1, intIterations);

    % Begin iteratively testing code!
    while intIterationNumber < intIterations
        intIterationNumber = intIterationNumber + 1;
        bContinue = false;
        try
            if stcSwitches.PlotTesting
                figure('Visible', 'off', 'Tag', '__uiTHelper__');
                intCodeFigures = 0;
            end
            tic();
            [cellAnswers{1:end-2}] = feval(strFName, cellArgs{:});
            vecCodeTime(intIterationNumber) = toc();
            if stcSwitches.FileTesting
                strFileNames = ls('*.txt');
                [intTextFiles, ~] = size(strFileNames);
                cellCodeFileNames = cell(1, intTextFiles);
                for i = 1:intTextFiles
                    cellCodeFileNames{i} = strFileNames(i, :);
                end
                    cellCodeAnswers = cell(1, numel(cellCodeFileNames) .* 2);
                    cellCodeAnswers(1:2:end) = cellCodeFileNames;
                for i = 1:intTextFiles
                    fidTemp = fopen(cellCodeFileNames{i}, 'r');
                    strTemp = fgetl(fidTemp);
                    intTempLine = 1;
                    while ischar(strTemp)
                        cellCodeFile{intTempLine} = strTemp; %#ok<AGROW>
                        intTempLine = intTempLine + 1;
                        strTemp = fgetl(fidTemp);
                    end
                    fclose(fidTemp);
                    delete(cellCodeFileNames{i});
                    cellCodeAnswers{1, 2 .* i} = cellCodeFile;
                end
                cellAnswers{end-1} = cellCodeAnswers;
            end
            if stcSwitches.ImageTesting
                stcImageFiles = [dir('*.jpg'), dir('*.png')];
                [~, intImageFiles] = size(stcImageFiles);
                cellCodeImageNames = cell(1, intImageFiles);
                for i = 1:intImageFiles
                    cellCodeImageNames{i} = stcImageFiles(i).Name;
                end
                cellCodeAnswers = cell(1, numel(cellCodeImageNames) .* 2);
                cellCodeAnswers(1:2:end) = cellCodeImageNames;
                for i = 1:intImageFiles
                    cellCodeAnswers{1, 2 .* i} = imread(stcImageFiles(i).Name);
                    delete(cellCodeImageNames{i});
                end
                cellAnswers{end} = cellCodeAnswers;
            end
            if stcSwitches.PlotTesting
                stcFigures = findall(0, 'Type', 'Figure');
                strOldFolder = cd(strFolder);
                for i = 1:numel(stcFigures)
                    if ~any(strcmp(stcFigures(i).Tag, cellTags))
                        intCodeFigures = intCodeFigures + 1;
                        saveas(stcFigures(i), sprintf('Figure%d_Code.jpg', intCodeFigures));
                        delete(stcFigures(i))
                    end
                end
                cd(strOldFolder);
            end
            delete(findobj('Tag', '__uiTHelper__'));
        catch ME
            if ~isempty(findobj('Tag', '__uiTHelper__'))
                delete(findobj('Tag', '__uiTHelper__'));
            end
            strCodeErrorID = ME.identifier;
            strCodeErrorMsg = ME.message;
            try
                figure('Visible', 'off', 'Tag', '__uiTHelper__');
                [cellSolutions{1:end-2}] = feval(strFSolnName, cellArgs{:});
                delete(findobj('Tag', '__uiTHelper__'));
                strError = sprintf('Code File:\n%s\n%s', ME.identifier, ME.message);
                bolPassed = false;
                if stcSwitches.FileTesting || stcSwitches.ImageTesting
                    stcFiles = [dir('*.jpg'), dir('*.txt'), dir('*.png')];
                    for fidFile = stcFiles
                        delete(fidFile.Name);
                    end
                end
                if stcSwitches.Details
                    cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Code Error!', intIterationNumber); 
                    cellViewer = cell(1, intOldLines + intIterationNumber);
                    for i = 1:intOldLines
                        cellViewer{i} = strOld(i, :);
                    end
                    cellViewer(intIterationNumber+1:end) = cellViewer(1:intOldLines);
                    cellViewer(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                    set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                end
                break
            catch ME
                if ~isempty(findobj('Tag', '__uiTHelper__'))
                    delete(findobj('Tag', '__uiTHelper__'));
                end
                if strcmp(strCodeErrorID, ME.identifier)
                    bolPassed = true;
                    bContinue = true;
                else
                    bolPassed = false;
                    strError = sprintf('Code File:\n%s\n%s\n\nSolution File:\n%s\n%s', strCodeErrorID, strCodeErrorMsg, ME.identifier, ME.message);
                    if stcSwitches.Details
                        cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Solution Error!', intIterationNumber); 
                        cellViewer = cell(1, intOldLines + intIterationNumber);
                        for i = 1:intOldLines
                            cellViewer{i} = strOld(i, :);
                        end
                        cellViewer(intIterationNumber+1:end) = cellViewer(1:intOldLines);
                        cellViewer(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                        set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                    end
                        break
                end
            end
        end
        
        try
            if stcSwitches.PlotTesting 
                figure('Tag', '__uiTHelper__', 'Visible', 'off');
                intSolnFigures = 0;
            end
            tic();
            [cellSolutions{1:end-2}] = feval(strFSolnName, cellArgs{:});
            vecSolnTime(intIterationNumber) = toc();
            if stcSwitches.FileTesting
                strFileNames = ls('*.txt');
                [intTextFiles, ~] = size(strFileNames);
                cellSolnFileNames = cell(1, intTextFiles);
                for i = 1:intTextFiles
                    cellSolnFileNames{i} = strFileNames(i, :);
                end
                cellSolnAnswers = cell(1, numel(cellSolnFileNames) .* 2);
                cellSolnAnswers(1:2:end) = cellSolnFileNames;
                for i = 1:intTextFiles
                    fidTemp = fopen(cellSolnFileNames{i}, 'r');
                    strTemp = fgetl(fidTemp);
                    intTempLine = 1;
                    while ischar(strTemp)
                        intTempLine = intTempLine + 1;
                        strTemp = fgetl(fidTemp);
                    end
                    fclose(fidTemp);
                    fopen(cellSolnFileNames{i}, 'r');
                    strTemp = fgetl(fidTemp);
                    cellSolnFile = cell(1, intTempLine);
                    while ischar(strTemp)
                        cellSolnFile{intTempLine} = strTemp;
                        intTempLine = intTempLine + 1;
                        strTemp = fgetl(fidTemp);
                    end
                    fclose(fidTemp);
                    delete(cellSolnFileNames{i});
                    cellSolnAnswers{1, i.*2} = cellSolnFile;
                end
                cellSolutions{end-1} = cellSolnAnswers;
            end
            if stcSwitches.ImageTesting
                stcImageFiles = [dir('*.jpg'), dir('*.png')];
                [~, intImageFiles] = size(stcImageFiles);
                cellSolnImageNames = cell(1, intImageFiles);
                for i = 1:intImageFiles
                    cellSolnImageNames{i} = stcImageFiles(i).Name;
                end
                cellSolnAnswers = cell(1, numel(cellSolnImageNames) .* 2);
                cellSolnAnswers(1:2:end) = cellCodeImageNames;
                for i = 1:intImageFiles
                    cellSolnAnswers{1, 2 .* i} = imread(stcImageFiles(i).Name);
                    delete(cellCodeImageNames{I});
                end
                cellSolutions{end} = cellSolnAnswers;
            end
            if stcSwitches.PlotTesting
                strOldFolder = cd(strFolder);
                stcFigures = findall(0, 'Type', 'Figure');
                for i = 1:numel(stcFigures)
                    if ~any(strcmp(stcFigures(i).Tag, cellTags))
                        intSolnFigures = intSolnFigures + 1;
                        saveas(stcFigures(i), sprintf('Figure%d_Soln.jpg', intSolnFigures));
                        delete(stcFigures(i));
                    end
                end
                cd(strOldFolder);
            end
            delete(findobj('Tag', '__uiTHelper__'));
        catch ME
            if ~bContinue
                strError = sprintf('Solution File:\n%s\n%s', ME.identifier, ME.message);
                bolPassed = false;
                if stcSwitches.Details
                    cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Solution Error!', intIterationNumber); 
                    cellViewer = cell(1, intOldLines + intIterationNumber);
                    for i = 1:intOldLines
                        cellViewer{i} = strOld(i, :);
                    end
                    cellViewer(intIterationNumber+1:end) = cellViewer(1:intOldLines);
                    cellViewer(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                    set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                end
                break
            end
        end
        
        if isequal(cellAnswers, cellSolutions) || bContinue
            if stcSwitches.Details
                cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Passed!', intIterationNumber);
            end
            if stcSwitches.PlotTesting
                strOldFolder = cd(strFolder);
                if intSolnFigures ~= intCodeFigures
                    if stcSwitches.Details
                        cViewer{intIterationNumber, 1} = [cViewer{intIterationNumber, 1} sprintf('\n>> Iteration #%d: Mismatch of number of figures!', intIterationNumber)];
                    end
                end
                if intSolnFigures <= intCodeFigures
                    vecPlotTemp = zeros(1, intSolnFigures) - 1;
                    for intTemp = 1:intSolnFigures
                        imgCode = imread(sprintf('Figure%d_Code.jpg', intTemp));
                        imgSoln = imread(sprintf('Figure%d_Soln.jpg', intTemp));
                        vecPlotTemp(intTemp) = sum(sum(sum(imgCode ~= imgSoln)));
                    end
                    delete('Figure*_*.jpg');
                    intTotalPixels = numel(imgCode);
                    vecPlotTemp(vecPlotTemp < 0) = [];
                    intDifferentPixels = mean(vecPlotTemp);
                    vecPlotAverage(intIterationNumber) = intDifferentPixels / intTotalPixels;
                    if stcSwitches.Details
                        cViewer{intIterationNumber, 1} = [cViewer{intIterationNumber, 1} sprintf('\n>> Iteration #%d: Plots Differed by %0.4f%%', vecPlotAverage(intIterationNumber))];
                    end
                elseif stcSwitches.Details
                    cViewer{intIterationNumber, 1} = [cViewer{intIterationNumber, 1} sprintf('\n>> Iteration #%d: Mismatch of number of figures!', intIterationNumber)];
                end
                cd(strOldFolder);
            end
            if intIterationNumber < intIterations
                i = 1;
                cellArgs = celCounter;
                while i <= intArgs
                    if stcSwitches.LoadDatabase
                        cellArgs{i} = cTests{intIterationNumber, i};
                    elseif cellDataType{i} == 7
                        [vararg, cellError] = customWorkSpace(cellFormulaic{i});
                        if cellError{1}
                            cstrError = cellError{3};
                            intErrorLines = numel(cstrError);
                            bolPassed = false;
                            if stcSwitches.Details
                                cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Formulaic Error!', intIterationNumber);
                                cellTemp = cell(1, intOldLines + intIterationNumber);
                                for j = 1:intOldLines
                                    cellTemp{j} = strOld(j, :);
                                end
                                cellTemp(intIterationNumber+1:end) = cellTemp(1:intOldLines);
                                cellTemp(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                                cellViewer = cell(intErrorLines + intIterationNumber + intOldLines);
                                cellViewer(1:intErrorLines) = cstrError;
                                cellViewer((intErrorLines+1):end) = cellTemp;
                                set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                            end
                            break
                        else
                            cellArgs{i} = vararg;
                        end
                    elseif cellDataType{i} == 1
                        tbBArgument = getappdata(hSoluCheck, 'tbBArgument');
                        [vararg, cellError] = customWorkSpace(['out = ' tbBArgument{i}.String]);
                        if cellError{1}
                            cstrError = cellError{3};
                            intErrorLines = numel(cstrError);
                            bolPassed = false;
                            if stcSwitches.Details
                                cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Formulaic Error!', intIterationNumber);
                                cellTemp = cell(1, intOldLines + intIterationNumber);
                                for j = 1:intOldLines
                                    cellTemp{j} = strOld(j, :);
                                end
                                cellTemp(intIterationNumber+1:end) = cellTemp(1:intOldLines);
                                cellTemp(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
                                cellViewer = cell(intErrorLines + intIterationNumber + intOldLines);
                                cellViewer(1:intErrorLines) = cstrError;
                                cellViewer((intErrorLines+1):end) = cellTemp;
                                set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
                            end
                            break
                        else
                            cellArgs{i} = vararg;
                        end
                    else
                        if (isnumeric(cellSteps{i})) && ~any(isnan(cellSteps{i})) && (~iscell(cellArgs{i}) && cellDataType{i} ~= 7 && cellDataType{i} ~= 1 && ~isstruct(cellArgs{i}))
                            celCounter{i} = celCounter{i} + cellSteps{i};

                            varTest = cellArgs{i} + cellSteps{i};
                            if stcSwitches.MaxMin
                                if ~any(any(varTest > cellRanges{i}(2) | varTest < cellRanges{i}(1)))
                                    cellArgs{i} = cellArgs{i} + cellSteps{i};
                                else
                                    cellArgs{i}(cellArgs{i} == cellRanges{i}(2)) = cellRanges{i}(1);
                                end
                            else
                                cellArgs{i} = cellArgs{i} + cellSteps{i};
                            end

                            if stcSwitches.Exempt
                                for j = 1:length(cellExempt{i})
                                    if isequal(varTest, cellExempt{i}{j})
                                        cellArgs{i}(cellArgs{i}==cellExempt{i}{j}) = cellStandIn{i}{1};
                                    end
                                end
                            end

                            if stcSwitches.ArrSize
                                try
                                    if cellArraySizes{i}(1) > 0
                                        cellArgs{i}(end+cellArraySizes{i}(1), :) = cellArraySizes{i}(3);
                                        celCounter{i}(end+cellArraySizes{i}(1), :) = cellArraySizes{i}(3);
                                    else
                                        cellArgs{i}((end+cellArraySizes{i}(1)+1):end, :) = [];
                                        celCounter{i}((end+cellArraySizes{i}(1)+1):end, :) = [];
                                    end

                                    if cellArraySizes{i}(2) > 0
                                        cellArgs{i}(:, end+cellArraySizes{i}(2)) = cellArraySizes{i}(3);
                                        celCounter{i}(:, end+cellArraySizes{i}(2)) = cellArraySizes{i}(3);
                                    else
                                        cellArgs{i}(:, (end+cellArraySizes{i}(2)+1):end) = [];
                                        celCounter{i}(:, (end+cellArraySizes{i}(2)+1):end) = [];
                                    end
                                catch ME
                                    bolPassed = false;
                                    strError = sprintf('Argument %d: Couldn''step array size.\n%s', intIterationNumber, ME.identifier);
                                    return
                                end
                            end

                            switch cellDataType{i}
                                case 2
                                    cellArgs{i} = char(cellArgs{i});
                                case 3
                                    cellArgs{i} = double(cellArgs{i});
                                case 6
                                    cellArgs{i} = cellArgs{i} < 2;
                            end
                        elseif iscell(cellArgs{i})
                            if stcSwitches.ArrSize
                                try
                                    if cellArraySizes{i}(1) > 0
                                        cellArgs{i}(end+cellArraySizes{i}(1), :) = {cellArraySizes{i}(3:end)};
                                        celCounter{i}(end+cellArraySizes{i}(1), :) = {cellArraySizes{i}(3:end)};
                                    else
                                        cellArgs{i}((end+cellArraySizes{i}(1)+1):end, :) = [];
                                        celCounter{i}((end+cellArraySizes{i}(1)+1):end, :) = [];
                                    end

                                    if cellArraySizes{i}(2) > 0
                                        cellArgs{i}(:, end+cellArraySizes{i}(2)) = {cellArraySizes{i}(3:end)};
                                        celCounter{i}(:, end+cellArraySizes{i}(2)) = {cellArraySizes{i}(3:end)};
                                    else
                                        cellArgs{i}(:, (end+cellArraySizes{i}(2)+1):end) = [];
                                        celCounter{i}(:, (end+cellArraySizes{i}(2)+1):end) = [];
                                    end
                                catch ME
                                    bolPassed = false;
                                    strError = sprintf('Argument %d: Couldn''step array size.\n%s', intIterationNumber, ME.identifier);
                                    return
                                end
                            end
                        end
                    end
                    i = i + 1;
                end
            end
        else
            bolPassed = false;
            if stcSwitches.Details
                cViewer{intIterationNumber, 1} = sprintf('>> Iteration #%d: Failed!', intIterationNumber);
            end
            break
        end
        objProgressBar.setValue(intIterationNumber);
        objProgressBar.setString(sprintf('%0.02f%%', intIterationNumber / intIterations * 100));
    end
    if stcSwitches.PlotTesting
        vecPlotAverage(vecPlotAverage < 0) = [];
        setappdata(hSoluCheck, 'vecPlotAverage', vecPlotAverage);
    end
    if stcSwitches.Details
        cellViewer = cell(1, intOldLines + intIterationNumber);
        for i = 1:intOldLines
            cellViewer{i} = strOld(i, :);
        end
        cellViewer(intIterationNumber+1:end) = cellViewer(1:intOldLines);
        cellViewer(1:intIterationNumber) = cViewer(intIterationNumber:-1:1);
        set(hViewer.tbVViewBox, 'String', strjoin(cellViewer, '\n'));
    end
    cd(strCurrentPath);
    recycle(strOldRecycle);
end