%The Mean of the even integers
%   given a vector of random, integer numbers, meanEven will return the
%   average of the even numbers

%{
    Test Cases:
%   out1 = meanEven([36,33,5,37,25,4,11,22,38,39])
%       out1 => 25
%
%   out2 = meanEven([6,39,38,19,32,6,17,37,32,38])
%       out2 => 25.3333
%
%   out3 = meanEven([26,1,34,37,27,30,30,16,26,7])
%       out3 => 27
%}
function [ iAvg ] = meanEven(vRandomInt)
%{
    Inventory:
    vRandomInt --> random integers; a vector of n length.
    
    iAvg --> the overall average; a number
%}
    vEvenInt = vRandomInt(mod(abs(vRandomInt), 2) == 0);
    iAvg = sum(sum(vEvenInt)) ./ length(vEvenInt);
end

