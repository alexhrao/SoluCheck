function varargout = SoluCheck(varargin)
% SOLUCHECK MATLAB code for SoluCheck.fig
%      SOLUCHECK, by itself, creates a new SOLUCHECK or raises the existing
%      singleton*.
%
%      H = SOLUCHECK returns the handle to a new SOLUCHECK or the handle to
%      the existing singleton*.
%
%      SOLUCHECK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SOLUCHECK.M with the given input arguments.
%
%      SOLUCHECK('Property','Value',...) creates a new SOLUCHECK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SoluCheck_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SoluCheck_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SoluCheck

% Last Modified by GUIDE v2.5 15-Sep-2015 23:53:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SoluCheck_OpeningFcn, ...
                   'gui_OutputFcn',  @SoluCheck_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SoluCheck is made visible.
function SoluCheck_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<*INUSL>
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SoluCheck (see VARARGIN)
global bFirstTime
bFirstTime = true;
% Choose default command line output for SoluCheck
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SoluCheck wait for user response (see UIRESUME)
 uiwait(handles.uiBSoluCheck);


% --- Outputs from this function are returned to the command line.
function varargout = SoluCheck_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
try
    if strcmpi(get(handles.uiBSoluCheck, 'waitstatus'), 'waiting')
        handles.output = 'No Output';
        guidata(hObject, handles);
        uiresume(handles.uiBSoluCheck);
    end
    varargout{1} = handles.output;
    assignin('base', 'cArguments', varargout{1});
catch
    disp('SoluCheck has exited successfully.')
end

function tbBFilePath_Callback(hObject, eventdata, handles) %#ok<*DEFNU>
% hObject    handle to tbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBFilePath as text
%        str2double(get(hObject,'String')) returns contents of tbBFilePath as a double

% --- Executes during object creation, after setting all properties.
function tbBFilePath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tbBSolutionPath_Callback(hObject, eventdata, handles)
% hObject    handle to tbBSolutionPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBSolutionPath as text
%        str2double(get(hObject,'String')) returns contents of tbBSolutionPath as a double


% --- Executes during object creation, after setting all properties.
function tbBSolutionPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBSolutionPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pbBFilePath.
function pbBFilePath_Callback(hObject, eventdata, handles)
% hObject    handle to pbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global bFirstTime
global sFileName
global sFilePath
global sSolutionName
global sSolutionPath
global iNargin
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
[sFileName, sFilePath] = uigetfile('*.m');
sOriginalFileName = get(handles.tbBFilePath, 'string');
if sFilePath ~= 0
    set(handles.stBTestResults, 'string', 'Test Results', 'BackgroundColor', [0.94 0.94 0.94]);
    set(handles.stBFunctionName, 'string', sFileName);
    if strcmp(get(handles.tbBSolutionPath, 'string'), 'Select your solution file...')
        set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
        sSolutionPath = sFilePath;
        sSolutionName = [sFileName(1:end-2) '_soln.p'];
    else
        if strcmp([sOriginalFileName(1:end-2) '_soln.p'], get(handles.tbBSolutionPath, 'string'))
            set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
            sSolutionPath = sFilePath;
            sSolutionName = [sFileName(1:end-2) '_soln.p'];
        end
    end
    if ~isempty(stBArgumentName) && ~bFirstTime;
        for i = 1:length(stBArgumentName)
            delete(stBArgumentName{i});
            delete(tbBArgument{i});
            delete(pmBDataType{i});
            delete(tbBStepSize{i});
            delete(stBDivider{i});
        end
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0, (33 .* i), 0, 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0, (33 .* i), 0, 0]);
    end
    bFirstTime = false;
    set(handles.tbBFilePath, 'string', [sFilePath sFileName]);
    addpath(sFilePath);
    iNargin = nargin(char(get(handles.tbBFilePath, 'string')));
    set(handles.stBArgumentNumber, 'string', num2str(iNargin));
    handles.stBArgumentName = zeros(1, iNargin);
    handles.tbBArgument = zeros(1, iNargin);
    handles.pmBDataType = zeros(1, iNargin);
    handles.tbBStepSize = zeros(1, iNargin);
    handles.stBDivider = zeros(1, iNargin);
    stBArgumentName = cell(1, iNargin);
    tbBArgument = cell(1, iNargin);
    pmBDataType = cell(1, iNargin);
    tbBStepSize = cell(1, iNargin);
    stBDivider = cell(1, iNargin);
    for i = 0:iNargin-1
        %Set the handles for arg names
        handles.stBArgumentName(i+1) = uicontrol(handles.uiBSoluCheck, 'Tag', ['stBArgumentName' num2str(i+1)], 'Style', 'text','string', sprintf('Argument %d:', i+1), 'FontSize', 10.0);
        setpixelposition(handles.stBArgumentName(i+1), getpixelposition(handles.stBArgumentNameExample) + [0, (-33 .* i), 0, 0]);
        stBArgumentName{i+ 1} = handles.stBArgumentName(i+1);
        %Set handles for arguments
        handles.tbBArgument(i+1) = uicontrol(handles.uiBSoluCheck, 'Tag', ['tbBArgument' num2str(i+1)], 'Style', 'edit', 'HorizontalAlignment', 'left', 'FontSize', 10.0);
        setpixelposition(handles.tbBArgument(i+1), getpixelposition(handles.tbBArgumentExample) + [0, (-33 .* i), 0, 0]);
        tbBArgument{i+1} = handles.tbBArgument(i+1);
        %Set handles for data types
        handles.pmBDataType(i+1) = uicontrol(handles.uiBSoluCheck, 'Tag', ['pmBDataType' num2str(i+1)], 'Style', 'popupmenu', 'String', {'Predefined Variable...', 'String', 'Number', 'Array', 'Cell Array', 'Custom...'}, 'FontSize', 10.0);
        setpixelposition(handles.pmBDataType(i+1), getpixelposition(handles.pmBDataTypeExample) + [0, (-33 .* i), 0, 0]);     
        pmBDataType{i+1} = handles.pmBDataType(i+1);
        %Set handles for the step sizes
        handles.tbBStepSize(i+1) = uicontrol(handles.uiBSoluCheck, 'Tag', ['tbBStepSize' num2str(i+1)], 'Style', 'edit', 'String', '1', 'HorizontalAlignment', 'left', 'FontSize', 10.0);
        setpixelposition(handles.tbBStepSize(i+1), getpixelposition(handles.tbBStepExample) + [0, (-33 .* i), 0, 0]);
        tbBStepSize{i+1} = handles.tbBStepSize(i+1);
        %Set handles for the dividers
        handles.stBDivider(i+1) = uicontrol(handles.uiBSoluCheck, 'Tag', ['stBDivider' num2str(i+1)], 'Style', 'text', 'HorizontalAlignment', 'left', 'string', get(handles.stBDividerExample, 'string'), 'FontSize', 4);
        setpixelposition(handles.stBDivider(i+1), getpixelposition(handles.stBDividerExample) + [0, (-33.*i), 0, 0]);
        stBDivider{i+1} = handles.stBDivider(i+1);
        %Move the two buttons
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0, -33, 0, 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0, -33, 0, 0]);
        %adjust the tab order
        uistack(handles.pbBStepSizeWhy, 'bottom');
        uistack(handles.pbBAdvancedOptions, 'bottom');
        uistack(handles.pbBTest, 'bottom');
        uistack(handles.pbBCancel, 'bottom');
    end
end

% --- Executes on button press in pbBSolutionFilePath.
function pbBSolutionFilePath_Callback(hObject, eventdata, handles)
% hObject    handle to pbBSolutionFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sSolutionName
global sSolutionPath
[sSolutionName, sSolutionPath] = uigetfile('*.p');
if sSolutionPath == 0
    set(handles.tbBSolutionPath, 'string', 'Select your solution file...');
else
    set(handles.tbBSolutionPath, 'string', [sSolutionPath sSolutionName]);
    addpath(sSolutionPath);
end

% --- Executes on button press in pbBAdvancedOptions.
function pbBAdvancedOptions_Callback(hObject, eventdata, handles)
% hObject    handle to pbBAdvancedOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox(sprintf('Sorry, but this part is still under construction. When it is complete, you''ll enjoy much finer control over the SoluCheck Engine, with much faster handling.\nEventually, here''s what you''ll be able to do:\n-Run the profiler on your code\n-Test against specific cases\n-Step array sizes\n-Step Custom Classes\n-And much more!'), 'SoluCheck');


% --- Executes on button press in pbBCancel.
function pbBCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbBCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    close;

% --- Executes on button press in pbBTest.
function pbBTest_Callback(hObject, eventdata, handles)
% hObject    handle to pbBTest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global iNargin
global sFileName
global sSolutionName
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
global cFinalArgs
bError = false;

cstBArgumentName = cell(1, iNargin);
ctbBArgument = cell(1, iNargin);
cDataType = cell(1, iNargin);
ctbBStepSize = cell(1, iNargin);
cstBDivider = cell(1, iNargin);
cArgs = cell(1, iNargin .* 2);

%Data Types
%1. Predefined Variable...
%2. String
%3. Number
%4. Array
%5. Cell Array
%6. Custom...
for i = 1:iNargin
    cstBArgumentName{i} = get(stBArgumentName{i}, 'string');
    ctbBArgument{i} = get(tbBArgument{i}, 'string');
    cDataType{i} = get(pmBDataType{i}, 'value');
    switch cDataType{i}
        case 1
            disp('SoluCheck cannot step defined variables at this time.\n');
            bError = true;
        case 2
            ctbBArgument{i} = char(ctbBArgument{i});
        case 3
            ctbBArgument{i} = str2double(ctbBArgument{i});
        case 4
            ctbBArgument{i} = str2num(ctbBArgument{i}); %#ok<ST2NM>
        case 5
            bError = true;
            disp('Unfortunately, this GUI is not equipped to handle cell arrays. To use a cell array, please refer to the Solver Command on the Command Line\n');
        case 6
            bError = true;
            disp('We can''step custom classes right now; expect more soon.\n');
        otherwise
            bError = true;
            fprintf('Error: Undefined data type in argument %d\n', i);
    end
    
    ctbBStepSize{i} = get(tbBStepSize{i}, 'string');
    cstBDivider{i} = get(stBDivider{i}, 'string');
    cArgs{2 .* i -1} = ctbBArgument{i};
    cArgs{2 .* i} = str2double(ctbBStepSize{i});
end

if ~bError
    [bPassed, intArgNumber, cFinalArgs] = SoluCheckEngine(sFileName(1:end-2),sSolutionName(1:end-2), str2double(get(handles.tbBIterations, 'string')), cArgs{:});
    if bPassed
        set(handles.stBTestResults, 'string', sprintf('We have successfully tested your function. Using %d iterations, we found no disagreements between your function and the given solution file.\nTest Passed!', intArgNumber), 'BackgroundColor', 'Green');
    else
        set(handles.stBTestResults, 'string', sprintf('We have successfully tested your function, and we found a disagreement. The iteration number was %d, and the arguments used for this iteration have been output to the command line.\nTest Failed!', intArgNumber), 'BackgroundColor', 'Red');
    end
else
    set(handles.stBTestResults, 'string', 'There was an error. Please try again.', 'BackgroundColor', 'Red');
end
handles.output = cFinalArgs;
guidata(hObject, handles);
uiresume;

function tbBIterations_Callback(hObject, eventdata, handles)
% hObject    handle to tbBIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBIterations as text
%        str2double(get(hObject,'String')) returns contents of tbBIterations as a double

% --- Executes during object creation, after setting all properties.
function tbBIterations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tbBArgumentExample_Callback(hObject, eventdata, handles)
% hObject    handle to tbBArgumentExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBArgumentExample as text
%        str2double(get(hObject,'String')) returns contents of tbBArgumentExample as a double


% --- Executes during object creation, after setting all properties.
function tbBArgumentExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBArgumentExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tbBStepExample_Callback(hObject, eventdata, handles)
% hObject    handle to tbBStepExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBStepExample as text
%        str2double(get(hObject,'String')) returns contents of tbBStepExample as a double
msgbox(class(get(handles.tbBStepExample, 'string')));


% --- Executes during object creation, after setting all properties.
function tbBStepExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBStepExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pbBStepSizeWhy.
function pbBStepSizeWhy_Callback(hObject, eventdata, handles)
% hObject    handle to pbBStepSizeWhy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
msgbox(sprintf('Unfortunately, due to the nature of SoluCheck, only certain arguments can be stepped.\n\nThese are the kinds of arguments that can be stepped:\nNumbers\nStrings\nArrays (NOT Cell Arrays)\nTables\n\nPlease note that, at this time, SoluCheck CANNOT step custom classes.'), 'SoluCheck');


% --- Executes on selection change in pmBDataTypeExample.
function pmBDataTypeExample_Callback(hObject, eventdata, handles)
% hObject    handle to pmBDataTypeExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmBDataTypeExample contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmBDataTypeExample


% --- Executes during object creation, after setting all properties.
function pmBDataTypeExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmBDataTypeExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

set(hObject, 'string', {'DataTypeExample', 'String', 'Number', 'Array', 'Cell Array', 'Custom...'});
