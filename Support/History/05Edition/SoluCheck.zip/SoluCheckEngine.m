function [bolPassed, intIterationsDone, celArgs] = SoluCheckEngine(strFName, strFSolnName, intIterations, varargin)
    iStop = length(varargin);
    celArgs = cell(1, nargin(strFName));
    cSteps = cell(1, nargin(strFName));
    cAnswers = cell(1, nargout(strFName));
    cSolutions = cell(1, nargout(strFSolnName));
    j = 1;
    bolPassed = true;
    if iStop / 2 ~= nargin(strFName)
        fprintf('Please enter the correct number of arguments! (%s)', num2str(nargin(strFName)));
    end
    i = 0;
    while i < iStop / 2
        cSteps{1, i+1} = varargin{2 .* (i + 1)};
        celArgs{1, i+1} = varargin{2 .* i + 1};
        i = i + 1;
    end
    %i = 0;
    while i < length(celArgs)
        if and(iscell(celArgs{1, i}), cSteps{1, i} ~= 'N/A')
            fprintf('Please enter a valid argument and step size combination. Specifically, %s, %s', celArgs{1, i}, cSteps{1, i});
        end
    end
    
    iArgs = length(celArgs);
    
    while j <= intIterations
        try
            [cAnswers{:}] = feval(strFName, celArgs{:});
        catch
            bolPassed = false;
            warning('Please be advised that your function resulted in an error.');
            return
        end
        try
            [cSolutions{:}] = feval(strFSolnName, celArgs{:});
        catch
            bolPassed = false;
            warning('Please be advised that the solution file caused an error.');
            return
        end
        if isequal(cAnswers, cSolutions)
            i = 1;
            while i <= iArgs
                if isnumeric(cSteps{1, i})
                    celArgs{1, i} = celArgs{1, i} + cSteps{1, i};
                end
                i = i + 1;
            end
        else
            bolPassed = false;
            %fprintf('There was a disagreement between your function and the solution. These were the arguments:%s.\rAnd the iteration Number was %d\n', s, j)            
            return
        end
        j = j + 1;
    end
    intIterationsDone = j - 1;
    if ~bolPassed        
        bolPassed = true;
    end
end