function varargout = AdvancedOptions(varargin)
% ADVANCEDOPTIONS SoluCheck figure
%   Do not call AdvancedOptions, as it cannot function ouside of SoluCheck.
%   
%   For command line access, call SoluCheckEngine from the command line,
%   then enter the required information. See Documentation for more.
% See also: SoluCheck

% Last Modified by GUIDE v2.5 30-Sep-2015 16:39:19
%#ok<*INUSL>
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AdvancedOptions_OpeningFcn, ...
                   'gui_OutputFcn',  @AdvancedOptions_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AdvancedOptions is made visible.
function AdvancedOptions_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<VANUS>
global hSoluCheck
global stcSwitches
hSoluCheck = findobj('Tag', 'uiBSoluCheck');

if isappdata(hSoluCheck, 'stcSwitches')
    stcSwitches = getappdata(hSoluCheck, 'stcSwitches');
else
    stcSwitches = struct('Profiler', false, ...
                         'Timing', false, ...
                         'SpecificSoln', false, ...
                         'LoadVariables', false, ...
                         'Details', false, ...
                         'MaxMin', false, ...
                         'Exempt', false, ...
                         'ArrSize', false, ...
                         'Notifications', false);
end

%stcSwitches --> a structure with these fields:
%fieldnames(stcSwitches) = {'Profiler', 'Timing', 'SpecificSoln',
%'LoadVariables', 'Details', 'MaxMin', 'Exempt', 'ArrSize')

% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to AdvancedOptions (see VARARGIN)

% Choose default command line output for AdvancedOptions
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

if stcSwitches.Profiler
    pbAProfiler.String = 'Profiler is ON'; %#ok<STRNU>
else
    pbAProfiler.String = 'Profiler is OFF'; %#ok<STRNU>
end

if stcSwitches.Timing
    pbATiming.String = 'Timing is ON'; %#ok<STRNU>
else
    pbATiming.String = 'Timing is OFF'; %#ok<STRNU>
end

% UIWAIT makes AdvancedOptions wait for user response (see UIRESUME)
% uiwait(handles.uiAAdvancedOptions);


% --- Outputs from this function are returned to the command line.
function varargout = AdvancedOptions_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pbAProfiler.
function pbAProfiler_Callback(hObject, eventdata, handles) %#ok<*INUSD,*DEFNU>
% hObject    handle to pbAProfiler (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
if strcmp(hObject.String, 'Profiler is OFF')
    hObject.String = 'Profiler is ON';
    stcSwitches.Profiler = true;
else
    hObject.String = 'Profiler is OFF';
    stcSwitches.Profiler = false;
end

% --- Executes on button press in pbATiming.
function pbATiming_Callback(hObject, eventdata, handles)
% hObject    handle to pbATiming (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
if strcmp(hObject.String, 'Timing is OFF')
    stcSwitches.Timing = true;
    hObject.String = 'Timing is ON';
else
    stcSwitches.Timing = false;
    hObject.String = 'Timing is OFF';
end

% --- Executes on button press in pbATestSpecific.
function pbATestSpecific_Callback(hObject, eventdata, handles)
% hObject    handle to pbATestSpecific (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in pbALoadVariables.
function pbALoadVariables_Callback(hObject, eventdata, handles)
% hObject    handle to pbALoadVariables (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
stcSwitches.LoadVariables = true;
LoadVariables;

% --- Executes on button press in pbAViewDetails.
function pbAViewDetails_Callback(hObject, eventdata, handles)
% hObject    handle to pbAViewDetails (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
global hSoluCheck
uiVViewer = figure('Name', 'SoluCheck Viewer', 'MenuBar', 'none', 'position', [100 100 500 500], 'Tag', 'uiVViewer', 'NumberTitle', 'off', 'ToolBar', 'none', 'WindowStyle', 'normal', 'HandleVisibility', 'on', 'CloseRequestFcn', @uiVViewer_Close);
hVViewer = guihandles(uiVViewer);
hVViewer.tbVViewBox = uicontrol('Parent', uiVViewer, 'Style', 'edit', 'position', [0 50 500, 450], 'Max', 1000, 'Min', 0, 'String', '>> ', 'HorizontalAlignment', 'left', 'Enable', 'inactive', 'Units', 'Normalized', 'Tag', 'tbVViewBox');
hVViewer.pbVClose = uicontrol(uiVViewer, 'Style', 'pushbutton', 'String', 'Close Viewer', 'Position', [250, 0, 250 50], 'Units', 'Normalized', 'Tag', 'pbVClose', 'Callback', @pbVClose_Callback);
hVViewer.pbVPrint = uicontrol(uiVViewer, 'Style', 'pushbutton', 'String', 'Print Screen', 'Position', [0, 0, 250, 50], 'Units', 'Normalized', 'Tag', 'pbVPrint', 'Callback', @pbVPrint_Callback);
stcSwitches.Details = true;
setappdata(hSoluCheck, 'stcSwitches', stcSwitches);
guidata(uiVViewer, hVViewer);

function uiVViewer_Close(hObject, callbackdata)
global stcSwitches
global hSoluCheck
stcSwitches.Details = false;
setappdata(hSoluCheck, 'stcSwitches', stcSwitches);
delete(gcf);

function pbVClose_Callback(hObject, callbackdata)
hDetails = findobj('Tag', 'uiVViewer');
delete(hDetails);

function pbVPrint_Callback(hObject, callbackdata)
print;

% --- Executes on button press in pbAMaxMin.
function pbAMaxMin_Callback(hObject, eventdata, handles)
% hObject    handle to pbAMaxMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
stcSwitches.MaxMin = true;
Range

% --- Executes on button press in pbAExempt.
function pbAExempt_Callback(hObject, eventdata, handles)
% hObject    handle to pbAExempt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
stcSwitches.Exempt = true;
Exempt

% --- Executes on button press in pbAArrSize.
function pbAArrSize_Callback(hObject, eventdata, handles)
% hObject    handle to pbAArrSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stcSwitches
stcSwitches.ArrSize = true;

% --- Executes on button press in pbAConfirm.
function pbAConfirm_Callback(hObject, eventdata, handles)
% hObject    handle to pbAConfirm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global hSoluCheck
global stcSwitches
%Here, we set all the arguments.
setappdata(hSoluCheck, 'stcSwitches', stcSwitches);
close;


% --- Executes when uiAAdvancedOptions is resized.
function uiAAdvancedOptions_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to uiAAdvancedOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hSoluCheck = findobj('Tag', 'uiBSoluCheck');
stcSwitches = getappdata(hSoluCheck, 'stcSwitches');
bFirstTime = getappdata(hSoluCheck, 'bFirstTime');
if stcSwitches.Profiler
    set(handles.pbAProfiler, 'String', 'Profiler is ON');
else
    set(handles.pbAProfiler, 'String', 'Profiler is OFF');
end

if stcSwitches.Timing
    set(handles.pbATiming, 'String', 'Timing in ON');
else
    set(handles.pbATiming, 'String', 'Timing is OFF');
end

if bFirstTime
    set(handles.pbAMaxMin, 'Enable', 'off');
    set(handles.pbAExempt, 'Enable', 'off');
    set(handles.pbAArrSize, 'Enable', 'off');
    set(handles.pbAArrElements, 'Enable', 'off');
else
    set(handles.pbAMaxMin, 'Enable', 'on');
    set(handles.pbAExempt, 'Enable', 'on');
    set(handles.pbAArrSize, 'Enable', 'on');
    set(handles.pbAArrElements, 'Enable', 'on');
end


% --- Executes on button press in pbAArrElements.
function pbAArrElements_Callback(hObject, eventdata, handles)
% hObject    handle to pbAArrElements (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pbANotifications.
function pbANotifications_Callback(hObject, eventdata, handles)
% hObject    handle to pbANotifications (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global stcSwitches
stcSwitches.Notifications = true;
msgbox('Under Construction: Get email alerts when simulations are complete')