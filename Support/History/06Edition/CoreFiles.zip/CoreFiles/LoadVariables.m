function varargout = LoadVariables(varargin)
% LOADVARIABLES SoluCheck figure
%    Do not call LoadVariables by itself; it cannot function without
%    SoluCheck active. For more information, see ADVANCED OPTIONS.
%
% See also: AdvancedOptions, SoluCheck

% Last Modified by GUIDE v2.5 30-Sep-2015 00:15:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @LoadVariables_OpeningFcn, ...
                   'gui_OutputFcn',  @LoadVariables_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before LoadVariables is made visible.
function LoadVariables_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<VANUS,*INUSL>
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to LoadVariables (see VARARGIN)
global cstFileName
global cpbBrowse
global cpbDelete
% Choose default command line output for LoadVariables
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes LoadVariables wait for user response (see UIRESUME)
% uiwait(handles.uiLLoadVariables);
cstFileName = {handles.stLFileName1};
cpbBrowse = {handles.pbLBrowse1};
cpbDelete = {handles.pbLDelete1};


% --- Outputs from this function are returned to the command line.
function varargout = LoadVariables_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pbLBrowse1.
function pbLBrowse1_Callback(hObject, eventdata, handles)
% hObject    handle to pbLBrowse1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global cstFileName
global cpbBrowse
global cpbDelete

intLineNumber = hObject.Tag;
intLineNumber = str2double(intLineNumber(end));
[strFileName, strFilePath] = uigetfile('*.mat', 'Select your variable file:');
if strFileName == 0;
    return
end
set(findobj('Tag', ['stLFileName' num2str(intLineNumber)]), 'String', strFileName);
set(findobj('Tag', ['pbLDelete' num2str(intLineNumber)]), 'Visible', 'on');
hLoadVariables = findobj('Tag', 'uiLLoadVariables');
cstFileName{intLineNumber + 1} = uicontrol(hLoadVariables, 'Style', 'text', 'String', '_____________________________________', 'FontSize', 10.0, 'Tag', ['stLFileName' num2str(intLineNumber + 1)], 'HorizontalAlignment', 'left');
setpixelposition(cstFileName{intLineNumber + 1}, getpixelposition(findobj('Tag', 'stLFileName1')) + [0 (-33 .* intLineNumber) 0 0])
cpbBrowse{intLineNumber + 1} = uicontrol(hLoadVariables, 'Style', 'pushbutton', 'String', 'Browse...', 'FontSize', 10.0, 'Tag', ['pbLBrowse' num2str(intLineNumber + 1)], 'Callback', @pbLBrowse1_Callback);
setpixelposition(cpbBrowse{intLineNumber + 1}, getpixelposition(findobj('Tag', 'pbLBrowse1')) + [0 (-33 .* intLineNumber) 0 0])
cpbDelete{intLineNumber + 1} = uicontrol(hLoadVariables, 'Style', 'pushbutton', 'Visible', 'off', 'String', 'Delete', 'FontSize', 10.0, 'Tag', ['pbLDelete' num2str(intLineNumber + 1)], 'Callback', @pbLDelete1_Callback);
setpixelposition(cpbDelete{intLineNumber + 1}, getpixelposition(findobj('Tag', 'pbLDelete1')) + [ 0 (-33 .* intLineNumber) 0 0]);

setpixelposition(findobj('Tag', 'pbLCancel'), getpixelposition(findobj('Tag', 'pbLCancel')) + [0 -33 0 0]);
setpixelposition(findobj('Tag', 'pbLConfirm'), getpixelposition(findobj('Tag', 'pbLConfirm')) + [0 -33 0 0]);
setappdata(findobj('Tag', 'uiBSoluCheck'), ['cFilePath' num2str(intLineNumber)], {strFilePath, strFileName})
setappdata(findobj('Tag', 'uiBSoluCheck'), 'intFileNumber', intLineNumber)


% --- Executes on button press in pbLDelete1.
function pbLDelete1_Callback(hObject, eventdata, handles)
% hObject    handle to pbLDelete1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
intNumber = hObject.Tag;
intNumber = str2double(intNumber(end));
hObject.Visible = 'off';
set(findobj('Tag', ['stLFileName' num2str(intNumber)]), 'Visible', 'off');
set(findobj('Tag', ['pbLBrowse' num2str(intNumber)]), 'Visible', 'off');
setappdata(findobj('Tag', 'uiBSoluCheck'), ['cFilePath' num2str(intNumber)], 0);
intTotal = getappdata(findobj('Tag', 'uiBSoluCheck'), 'intFileNumber');
for i = intNumber:intTotal + 1
    k = findobj('Tag', ['stLFileName' num2str(i)]);
    setpixelposition(k, getpixelposition(k) + [0 33 0 0]);
    k = findobj('Tag', ['pbLBrowse' num2str(i)]);
    setpixelposition(k, getpixelposition(k) + [0 33 0 0]);
    k = findobj('Tag', ['pbLDelete' num2str(i)]);
    setpixelposition(k, getpixelposition(k) + [0 33 0 0]);
end

% --- Executes on button press in pbLConfirm.
function pbLConfirm_Callback(hObject, eventdata, handles) %#ok<DEFNU>
% hObject    handle to pbLConfirm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
intFileNumber = getappdata(findobj('Tag', 'uiBSoluCheck'), 'intFileNumber');
for i = 1:intFileNumber
    cFileParts = getappdata(findobj('Tag', 'uiBSoluCheck'), ['cFilePath' num2str(i)]);
    if iscell(cFileParts)
        addpath(strjoin(cFileParts, ''));
        strLoad = ['load(''' char(cFileParts{2}) ''');'];
        try
            evalin('base', strLoad);
        catch ME
            if strcmp(ME.identifier, 'MATLAB:load:couldNotReadFile')
                msgbox(sprintf('File #%d: The file %s does not exist!', i, cFileParts{2}), 'Loading Variables');
            else
                msgbox(sprintf('File #%d: An unknown error ocurred; most likely a read permission error. Please try again', i), 'Loading Variables');
            end
        end
        rmpath(strjoin(cFileParts, ''));
    end
end
close;


% --- Executes on button press in pbLCancel.
function pbLCancel_Callback(hObject, eventdata, handles) %#ok<*INUSD,DEFNU>
% hObject    handle to pbLCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;


% --- Executes when uiLLoadVariables is resized.
function uiLLoadVariables_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to uiLLoadVariables (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
