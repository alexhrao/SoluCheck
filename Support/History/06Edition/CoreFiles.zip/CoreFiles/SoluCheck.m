function varargout = SoluCheck(varargin)
% SOLUCHECK Code for SoluCheck Platform
%      SOLUCHECK, by itself, creates a new SOLUCHECK or raises the existing
%      singleton.
%
%      H = SOLUCHECK returns the handle to a new SOLUCHECK or the handle to
%      the existing singleton.
%      
%      For More help, see the SoluCheck Documentation, which should have
%      been included with your install of SoluCheck. Alternatively, you can
%      contact SoluWare at SoluWare_Help@SoluWare.com.
%
% See also: AdvancedOptions, SoluCheckEngine

% Last Modified by GUIDE v2.5 29-Sep-2015 14:11:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SoluCheck_OpeningFcn, ...
                   'gui_OutputFcn',  @SoluCheck_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SoluCheck is made visible.
function SoluCheck_OpeningFcn(hObject, eventdata, handles, varargin) %#ok<VANUS,*INUSL>
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SoluCheck (see VARARGIN)
global bFirstTime
global bDone
global vecOldSize
bDone = true;
bFirstTime = true;
setappdata(hObject, 'bFirstTime', bFirstTime);
vecOldSize = [1000 650];
warning('off', 'all');
if ~isappdata(hObject, 'stcSwitches')
    stcSwitches= struct('Profiler', false, ...
                    'Timing', false, ...
                    'SpecificSoln', false, ...
                    'ConstantSoln', false, ...
                    'Details', false, ...
                    'MaxMin', false, ...
                    'Exempt', false, ...
                    'ArrSize', false, ...
                    'Notifications', false);
    setappdata(hObject, 'stcSwitches', stcSwitches);
end
% Choose default command line output for SoluCheck
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SoluCheck wait for user response (see UIRESUME)
% uiwait(handles.uiBSoluCheck);


% --- Outputs from this function are returned to the command line.
function varargout = SoluCheck_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
global cFinalArgs
global cAnswers
global cSolutions
try
    varargout{1} = handles.output;
    assignin('base', 'cArguments', cFinalArgs);
    assignin('base', 'cAnswers', cAnswers);
    assignin('base', 'cSolutions', cSolutions);
catch ME
    fprintf('SoluCheck has exited violently.\n%s', ME.identifier)
end

function tbBFilePath_Callback(hObject, eventdata, handles) %#ok<*INUSD,*DEFNU>
% hObject    handle to tbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBFilePath as text
%        str2double(get(hObject,'String')) returns contents of tbBFilePath as a double

% --- Executes during object creation, after setting all properties.
function tbBFilePath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tbBSolutionPath_Callback(hObject, eventdata, handles)
% hObject    handle to tbBSolutionPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBSolutionPath as text
%        str2double(get(hObject,'String')) returns contents of tbBSolutionPath as a double


% --- Executes during object creation, after setting all properties.
function tbBSolutionPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBSolutionPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pbBFilePath.
function pbBFilePath_Callback(hObject, eventdata, handles)
% hObject    handle to pbBFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global bFirstTime
global sFileName
global sFilePath
global sSolutionName
global sSolutionPath
global iNargin
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
global intScrollerValue
global vecFirstPosn

[sFileName, sFilePath] = uigetfile('*.m');
set(handles.stBTestResults, 'String', 'Loading...', 'ForegroundColor', 'black', 'Background', [.94 .94 .94]);
pause('on');
pause(1/1000);
pause('off');
sOriginalFileName = get(handles.tbBFilePath, 'string');
if sFilePath ~= 0
    try
        addpath(sFilePath);
        iNargin = nargin([sFilePath sFileName]);
        setappdata(handles.uiBSoluCheck, 'iNargin', iNargin);
    catch
        set(handles.stBTestResults, 'string', 'Please select a valid function file!', 'BackgroundColor', 'Yellow');
        return
    end
    if iNargin < 0
        set(handles.stBTestResults, 'string', 'Please select a function that does NOT take in a variable number of inputs!', 'BackgroundColor', 'Yellow');
        return
    end
    set(handles.pbBTest, 'Enable', 'on');
    set(handles.stBFunctionName, 'string', sFileName);
    if strcmp(get(handles.tbBSolutionPath, 'string'), 'Select your solution file...')
        set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
        sSolutionPath = sFilePath;
        sSolutionName = [sFileName(1:end-2) '_soln.p'];
    else
        if strcmp([sOriginalFileName(1:end-2) '_soln.p'], get(handles.tbBSolutionPath, 'string'))
            set(handles.tbBSolutionPath, 'string', [sFilePath sFileName(1:end-2) '_soln.p']);
            sSolutionPath = sFilePath;
            sSolutionName = [sFileName(1:end-2) '_soln.p'];
        end
    end
    if ~isempty(stBArgumentName) && ~bFirstTime;
        for i = 1:length(stBArgumentName)
            delete(stBArgumentName{i});
            delete(tbBArgument{i});
            delete(pmBDataType{i});
            delete(tbBStepSize{i});
            delete(stBDivider{i});
        end
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0, (33 .* i), 0, 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0, (33 .* i), 0, 0]);
    end
    bFirstTime = false;
    setappdata(handles.uiBSoluCheck, 'bFirstTime', bFirstTime);
    set(handles.tbBFilePath, 'string', [sFilePath sFileName]);
    set(handles.stBArgumentNumber, 'string', num2str(iNargin));
    handles.stBArgumentName = zeros(1, iNargin);
    handles.tbBArgument = zeros(1, iNargin);
    handles.pmBDataType = zeros(1, iNargin);
    handles.tbBStepSize = zeros(1, iNargin);
    handles.stBDivider = zeros(1, iNargin);
    stBArgumentName = cell(1, iNargin);
    tbBArgument = cell(1, iNargin);
    pmBDataType = cell(1, iNargin);
    tbBStepSize = cell(1, iNargin);
    stBDivider = cell(1, iNargin);
    for i = 0:iNargin-1
        %Set the handles for arg names
        stBArgumentName{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['stBArgumentName' num2str(i+1)], 'Style', 'text','string', sprintf('Argument %d:', i+1), 'FontSize', 10.0);
        setpixelposition(stBArgumentName{i+1}, getpixelposition(handles.stBArgumentNameExample) + [0, (-33 .* i), 0, 0]);
        %Set handles for arguments
        tbBArgument{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['tbBArgument' num2str(i+1)], 'Style', 'edit', 'HorizontalAlignment', 'left', 'FontSize', 10.0);
        setpixelposition(tbBArgument{i+1}, getpixelposition(handles.tbBArgumentExample) + [0, (-33 .* i), 0, 0]);
        %Set handles for data types
        pmBDataType{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['pmBDataType' num2str(i+1)], 'Style', 'popupmenu', 'String', {'Predefined Variable', 'String', 'Number', 'Array', 'Cell Array', 'Formulaic...'}, 'FontSize', 10.0, 'Callback', @pmBData_Callback);
        setpixelposition(pmBDataType{i+1}, getpixelposition(handles.pmBDataTypeExample) + [0, (-33 .* i), 0, 0]);     
        %Set handles for the step sizes
        tbBStepSize{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['tbBStepSize' num2str(i+1)], 'Style', 'edit', 'String', '1', 'HorizontalAlignment', 'left', 'FontSize', 10.0);
        setpixelposition(tbBStepSize{i+1}, getpixelposition(handles.tbBStepExample) + [0, (-33 .* i), 0, 0]);
        %Set handles for the dividers
        stBDivider{i+1} = uicontrol(handles.uiBSoluCheck, 'Tag', ['stBDivider' num2str(i+1)], 'Style', 'text', 'HorizontalAlignment', 'left', 'string', get(handles.stBDividerExample, 'string'), 'FontSize', 4);
        setpixelposition(stBDivider{i+1}, getpixelposition(handles.stBDividerExample) + [0, (-33.*i), 0, 0]);
        %Move the two buttons
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0, -33, 0, 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0, -33, 0, 0]);
        %adjust the tab order
        uistack(handles.pbBStepSizeWhy, 'bottom');
        uistack(handles.pbBAdvancedOptions, 'bottom');
        uistack(handles.pbBTest, 'bottom');
        uistack(handles.pbBCancel, 'bottom');
    end
    set(handles.stBTestResults, 'String', 'You''ve selected a valid file; now click Test to continue, or Advanced Options to customize your test.', 'ForegroundColor', 'black', 'BackgroundColor', 'white');
else
    set(handles.stBTestResults, 'String', 'Test Results');
end

vecPosn = getpixelposition(handles.pbBTest);
vecPosn = vecPosn(2);
if vecPosn < 0
    set(handles.slBYScroller, 'Min', 0.00, 'Max', abs(vecPosn), 'Value', abs(vecPosn), 'Visible', 'on');
else
    set(handles.slBYScroller, 'Min', 1.0, 'Max', 1.0, 'Value', 0);
end
intScrollerValue = abs(vecPosn);
vecFirstPosn = getpixelposition(handles.pbBTest);

% --- Executes on button press in pbBSolutionFilePath.
function pbBSolutionFilePath_Callback(hObject, eventdata, handles)
% hObject    handle to pbBSolutionFilePath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sSolutionName
global sSolutionPath
[sSolutionName, sSolutionPath] = uigetfile('*.p');
if sSolutionPath == 0
    set(handles.tbBSolutionPath, 'string', 'Select your solution file...');
else
    set(handles.tbBSolutionPath, 'string', [sSolutionPath sSolutionName]);
    addpath(sSolutionPath);
end

% --- Executes on button press in pbBAdvancedOptions.
function pbBAdvancedOptions_Callback(hObject, eventdata, handles)
% hObject    handle to pbBAdvancedOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AdvancedOptions


% --- Executes on button press in pbBCancel.
function pbBCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbBCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
    
    

% --- Executes on button press in pbBTest.
function pbBTest_Callback(hObject, eventdata, handles)
% hObject    handle to pbBTest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global iNargin
global sFileName
global sSolutionName
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
global cFinalArgs
global cAnswers
global cSolutions
global bDone

bError = false;
bDone = false; %#ok<NASGU>
set(handles.stBTestResults, 'String', 'Please Wait - Testing...', 'BackgroundColor', 'blue', 'ForegroundColor', 'white'); 
pause('on');
pause(1/1000);
pause('off')
stcSwitches = getappdata(handles.uiBSoluCheck, 'stcSwitches');
cstBArgumentName = cell(1, iNargin);
ctbBArgument = cell(1, iNargin);
cDataType = cell(1, iNargin);
ctbBStepSize = cell(1, iNargin);
cstBDivider = cell(1, iNargin);
cArgs = cell(1, iNargin .* 2);

%Data Types
%1. Predefined Variable
%2. String
%3. Number
%4. Array
%5. Cell Array
%6. Formulaic...
cClass = {'Predefined Variable', 'String', 'Number', 'Array', 'Cell Array', 'Formulaic...'};

sError = '';
for i = 1:iNargin
    cstBArgumentName{i} = get(stBArgumentName{i}, 'string');
    ctbBArgument{i} = get(tbBArgument{i}, 'string');
    cDataType{i} = get(pmBDataType{i}, 'value');
    switch cDataType{i}
        case 1
            try
                ctbBArgument{i} = evalin('base', char(ctbBArgument{i}));
                if isempty(ctbBArgument{i}) || any(any(isnan(ctbBArgument{i})))
                    bError = true;
                    sError = [sError sprintf('Argument #%d: The variable found resulted in a null value.\n', i)];   %#ok<AGROW>
                end
            catch ME
                bError = true;
                if strcmp(ME.identifier, 'MATLAB:UndefinedFunction')
                    sError = [sError sprintf('Argument #%d: The variable is not currently defined.\n', i)];    %#ok<AGROW>
                else
                    sError = [sError sprintf('Argument #%d: Evaluation failed.\n', i)];  %#ok<AGROW>
                end
                % I don't think this is really working to be honest.
                %[~, sWarningID] = lastwarn;
                %if strcmp(sWarningID, 'MATLAB:namelengthmaxexceeded')
                %    sError = [sError sprintf('Argument #%d: the variable length is too long!\n', i)];         %#ok<AGROW>
                %end
            end
        case 2
            try
                ctbBArgument{i} = char(ctbBArgument{i});
                if isempty(ctbBArgument{i}) || any(any(isnan(ctbBArgument{i})))
                    bError = true;
                    sError = [sError sprintf('Argument #%d: Conversion to class %s resulted in a null value.\n', i, cClass{2})];  %#ok<AGROW>
                end
            catch %#ok<*CTCH>
                bError = true;
                sError = [sError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{2})];   %#ok<AGROW>
            end
        case 3
            try
                ctbBArgument{i} = str2double(ctbBArgument{i});
                if isempty(ctbBArgument{i}) || any(any(isnan(ctbBArgument{i})))
                    bError = true;
                    sError = [sError sprintf('Argument #%d: Conversion to class %s resulted in a null value.\n', i, cClass{3})];    %#ok<AGROW>
                end
            catch
                bError = true;
                sError = [sError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{3})];  %#ok<AGROW>
            end
        case 4
            try
                ctbBArgument{i} = evalin('base', ctbBArgument{i});
                if isempty(ctbBArgument{i}) || any(any(isnan(ctbBArgument{i})))
                    bError = true;
                    sError = [sError sprintf('Argument #%d: Conversion to class %s resulted in a null value.\n', i, cClass{4})];    %#ok<AGROW>
                end
            catch
                bError = true;
                sError = [sError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{4})];   %#ok<AGROW>
            end
        case 5
            try
                ctbBArgument{i} = eval(ctbBArgument{i});
                if ~iscell(ctbBArgument{i})
                    bError = true;
                    sError = [sError sprintf('Argument #%d: No cell array detected.\n', i)]; %#ok<AGROW>
                else
                    sError = [sError sprintf('Argument #%d: A cell array was detected and was not stepped.\n', i)]; %#ok<AGROW>
                end
            catch
                bError = true;
                sError = [sError sprintf('Argument #%d: Conversion to class %s failed.\n', i, cClass{5})];    %#ok<AGROW>
            end
        case 6
            try
                ctbBArgument{i} = evalin('base', ctbBArgument{i});
                sError = [sError sprintf('Argument #%d: A Formulaic Entry was detected and was not stepped.\n', i)];    %#ok<AGROW>
            catch ME
                bError = true;
                sError = [sError sprintf('Argument #%d: Unable to evaluate formula. Error Message:\n%s\n', i, ME.message)]; %#ok<AGROW>
            end
        otherwise
            bError = true;
            sError = [sError sprintf('Argument #%d: Undefined data type.\n', i)]; %#ok<AGROW>
    end

    ctbBStepSize{i} = get(tbBStepSize{i}, 'string');
    if strcmp(ctbBStepSize{i}, '0') || ischar(ctbBStepSize)
        ctbBStepSize{i} = 'N/A';
    else
        ctbBStepSize{i} = str2double(ctbBStepSize{i});
    end
    cstBDivider{i} = get(stBDivider{i}, 'string');
    cArgs{2 .* i -1} = ctbBArgument{i};
    cArgs{2 .* i} = ctbBStepSize{i};
end

if ~bError
    [bPassed, sEngineError, intArgNumber, cFinalArgs, cAnswers, cSolutions, vecTime1, vecTime2] = SoluCheckEngine(sFileName(1:end-2),sSolutionName(1:end-2), str2double(get(handles.tbBIterations, 'string')), cDataType, cArgs{:});
    
    if intArgNumber == 1
        sArgNumber = '1 iteration';
    else
        sArgNumber = sprintf('%d iterations', intArgNumber);
    end
    
    if bPassed
        set(handles.stBTestResults, 'string', sprintf(['We have successfully tested your function. Using %s, we found no disagreements between your function and the given solution file.\nTest Passed!'...
            '\nErrors Generated:\n%s'], sArgNumber, sError), 'BackgroundColor', 'Green', 'ForegroundColor', 'black');
    elseif isempty(sEngineError)
        set(handles.stBTestResults, 'string', sprintf(['We have successfully tested your function, and we found a disagreement. The iteration number was %d, and the arguments used for this iteration, '...
            'as well as your answers and the solutions, have been output to the command line.\nTest Failed!'], intArgNumber), 'BackgroundColor', 'Red', 'ForegroundColor', 'white');
    else
        set(handles.stBTestResults, 'string', sprintf('We were unsuccessful in testing the functions; Here''s the error message that was last produced:\n%s\nTest Error!', sEngineError), 'BackgroundColor', 'Yellow', 'ForegroundColor', 'black');
    end
    
    pause('on');
    pause(1/10000);
    pause('off');
    
    if stcSwitches.Timing
        assignin('base', 'vecCodeTime', vecTime1);
        assignin('base', 'vecSolnTime', vecTime2);
        uiPPlots = figure('ToolBar', 'none', 'MenuBar', 'None', 'Name', 'SoluCheck Code Analyzer', 'NumberTitle', 'off'); %#ok<NASGU>
        plot(1:intArgNumber, vecTime1, 1:intArgNumber, vecTime2);
        legend(sprintf('Code Time, Average of %ds', mean(vecTime1)), sprintf('Solution Time, Average of %ds', mean(vecTime2)));
        title(sprintf('SoluCheck Code Analyzer: %s', sFileName));
        xlabel('Number of Iterations');
        ylabel('Time to compute, in seconds');
    end
    
    if stcSwitches.Profiler
        profile('viewer');
    end
else
    set(handles.stBTestResults, 'string', sprintf('There were one or more errors in your arguments. Please try again. Details:\n%s', sError), 'BackgroundColor', 'Yellow', 'ForegroundColor', 'black');
end
    if stcSwitches.Notifications
    end
bDone = true;

function pbPClose_Callback(hObject, callbackdata)
    delete(hObject.Parent);
    
function tbBIterations_Callback(hObject, eventdata, handles)
% hObject    handle to tbBIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBIterations as text
%        str2double(get(hObject,'String')) returns contents of tbBIterations as a double


% --- Executes during object creation, after setting all properties.
function tbBIterations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tbBArgumentExample_Callback(hObject, eventdata, handles)
% hObject    handle to tbBArgumentExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBArgumentExample as text
%        str2double(get(hObject,'String')) returns contents of tbBArgumentExample as a double


% --- Executes during object creation, after setting all properties.
function tbBArgumentExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBArgumentExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function tbBStepExample_Callback(hObject, eventdata, handles)
% hObject    handle to tbBStepExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tbBStepExample as text
%        str2double(get(hObject,'String')) returns contents of tbBStepExample as a double


% --- Executes during object creation, after setting all properties.
function tbBStepExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tbBStepExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pbBStepSizeWhy.
function pbBStepSizeWhy_Callback(hObject, eventdata, handles)
% hObject    handle to pbBStepSizeWhy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
msgbox(sprintf(['Unfortunately, due to the nature of SoluCheck, only certain'...
    'arguments can be stepped.\n\nThese are the kinds of arguments that can be stepped:\nNumbers\nStrings\nArrays'...
    '(NOT Cell Arrays)\nTables\n\nPlease note that, at this time, SoluCheck CANNOT step custom classes.']), 'SoluCheck');


% --- Executes on selection change in pmBDataTypeExample.
function pmBDataTypeExample_Callback(hObject, eventdata, handles)
% hObject    handle to pmBDataTypeExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmBDataTypeExample contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmBDataTypeExample


% --- Executes during object creation, after setting all properties.
function pmBDataTypeExample_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmBDataTypeExample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

set(hObject, 'string', {'DataTypeExample', 'String', 'Number', 'Array', 'Cell Array', 'Custom...'});

function pbCConfirm_Callback(hObject, callbackdata, strName)
global tbBArgument
global tbCCommandLine
if strcmp(tbCCommandLine.String(1:2), '>>')
    tbCCommandLine.String = tbCCommandLine.String(3:end);
elseif strcmp(tbCCommandLine.String(1), '>')
    tbCCommandLine.String = tbCCommandLine.String(2:end);
end
intArgument = str2double(strName(end-(end-12):end));
set(tbBArgument{intArgument}, 'String', tbCCommandLine.String);
close;

function pbCCancel_Callback(hObject, callbackdata, strName)
close;
    
function pmBData_Callback(hObject, callbackdata)
    global tbCCommandLine
    if hObject.Value == 6
        uiCCommandWindow = figure('Visible', 'off', 'Name', 'SoluCheck: Formulaic Entry', 'NumberTitle', 'off', 'position', [350 50 500 550]);
        tbCCommandLine = uicontrol('Style', 'edit', 'position', [0, 50, 500, 500], 'HorizontalAlignment', 'left', 'Max', 100, 'Min', 0, 'Units', 'Normalized', 'String', '>> ');
        pbCConfirm = uicontrol('Style', 'pushbutton', 'string', 'Confirm', 'position', [250, 0, 250, 50], 'Callback', {@pbCConfirm_Callback, hObject.Tag}, 'Units', 'Normalized'); %#ok<NASGU>
        pbCCancel = uicontrol('Style', 'pushbutton', 'String', 'Cancel', 'position', [0, 0, 250, 50], 'Callback', {@pbCCancel_Callback, hObject.Tag}, 'Units', 'Normalized'); %#ok<NASGU>
        uiCCommandWindow.Visible = 'on';
        uicontrol(tbCCommandLine);
    end
    
    
% --- Executes when uiBSoluCheck is resized.
function uiBSoluCheck_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to uiBSoluCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global vecOldSize
global iNargin
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
global bFirstTime
global intScrollerValue

vecPosition = getpixelposition(hObject);
vecNewSize = vecPosition(3:4);
vecDifference = [0, (vecNewSize(2)-vecOldSize(2)), 0, 0];
celNames = fieldnames(handles)';
celFields = {stBArgumentName, tbBArgument, pmBDataType, tbBStepSize, stBDivider};
for i = 2:length(celNames)-1
    if ~strcmp(celNames{i}, 'pbBStepSizeWhy') && ~strcmp(celNames{i}, 'pbBAdvancedOptions')
        k = findobj('Tag', celNames{i});
        setpixelposition(k, getpixelposition(k) + vecDifference);
    end
end
if ~bFirstTime
    for i = 1:length(celFields)
        for j = 1:iNargin
            k = celFields{i}{j};
            setpixelposition(k, getpixelposition(k) + vecDifference);
        end
    end
end

vecSliderPosn = getpixelposition(handles.slBYScroller);
vecTopPosn = getpixelposition(handles.stBTop);
vecNewPosn = [vecSliderPosn(1), 0, vecSliderPosn(3), vecTopPosn(2)];
setpixelposition(handles.slBYScroller, vecNewPosn);
vecTestButtonPosn = getpixelposition(handles.pbBTest);

if vecTestButtonPosn(2) >= 0
    set(handles.slBYScroller, 'Visible', 'off');
    
    if (get(handles.slBYScroller, 'Value') ~= get(handles.slBYScroller, 'Max')) && ~bFirstTime
        % Code that moves everything back up. We know the value of max, and
        % we know the value. so, we should act like we are moving
        % everything back up, right? To do this, we should move everything
        % by the value of our scroller, right?
        intDifference = get(handles.slBYScroller, 'Value') - get(handles.slBYScroller, 'Max');
        for i = 1:length(celFields)
            for j = 1:iNargin
                k = celFields{i}{j};
                setpixelposition(k, getpixelposition(k) + [0 intDifference 0 0]);
                k.Visible = 'on';
            end
        end
        handles.slBYScroller.Value = handles.slBYScroller.Max;
        setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0 intDifference 0 0]);
        setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0 intDifference 0 0]);
    end
else
    intScrollerValue = abs(vecTestButtonPosn(2));
    set(handles.slBYScroller, 'Visible', 'on', 'Max', abs(vecTestButtonPosn(2)), 'Value', abs(vecTestButtonPosn(2)));
end
% 
% if vecTestButtonPosn(2) >= 0
%     set(handles.slBYScroller, 'Max', 1.0, 'Min', 1.0, 'Value', 0.0);
% else
%     set(handles.slBYScroller, 'Min', 0.00, 'Max', abs(vecTestButtonPosn(2)), 'Value', abs(vecTestButtonPosn(2)));
%     intScrollerValue = abs(vecTestButtonPosn(2));
% end
vecOldSize = vecNewSize;


% --- Executes on slider movement.
function slBYScroller_Callback(hObject, eventdata, handles)
% hObject    handle to slBYScroller (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global iNargin
global intScrollerValue
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
global bFirstTime
if isempty(intScrollerValue)
    intScrollerValue = get(hObject, 'Max');
end
intTop = getpixelposition(handles.stBTop);
celNames = {stBArgumentName, tbBArgument, pmBDataType, tbBStepSize, stBDivider};
intDifference = -(get(hObject, 'Value') - intScrollerValue);
if ~bFirstTime
    for i = 1:length(celNames)
        for j = 1:iNargin
            k = celNames{i}{j};
            setpixelposition(k, getpixelposition(k) + [0 intDifference 0 0]);
            intPosn = getpixelposition(k);
            if intPosn(2) + intPosn(4) >= intTop(2)
                set(k, 'Visible', 'off');
            else
                set(k, 'Visible', 'on');
            end
        end
    end
setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + [0 intDifference 0 0]);
setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + [0 intDifference 0 0]);
end

intScrollerValue = get(hObject, 'Value');
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slBYScroller_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slBYScroller (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on scroll wheel click while the figure is in focus.
function uiBSoluCheck_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to uiBSoluCheck (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)
global bFirstTime
global iNargin
global stBArgumentName
global tbBArgument
global pmBDataType
global tbBStepSize
global stBDivider
global intScrollerValue
global vecFirstPosn

if isempty(vecFirstPosn)
    vecFirstPosn = getpixelposition(handles.pbBTest);
end
vecChange = [0 ((eventdata.VerticalScrollCount ./ abs(eventdata.VerticalScrollCount) .* eventdata.VerticalScrollAmount)) 0 0];

vecPosn = getpixelposition(handles.pbBTest);

if (vecPosn(2) + vecChange(2) <= vecFirstPosn(2)) && (vecChange(2) < 0)
    return
end

if vecPosn(2) + vecChange(2) >= 0
    vecChange = [0 vecPosn(2) 0 0];
end
celFields = {stBArgumentName, tbBArgument, pmBDataType, tbBStepSize, stBDivider};

if ~bFirstTime && vecPosn(2) < 0
    %Don't scroll if the y posn is not less than 0!!
    %Also, if we WOULD scroll past the end, we need to just go to the end;
    %not pass it!!!!
    % We need to find the distance to the end (pbBTest = 0), then apply
    % this to the given formula
    for i = 1:length(celFields)
        for j = 1:iNargin
            k = celFields{i}{j};
            setpixelposition(k, getpixelposition(k) + vecChange);
            vecKPosition = getpixelposition(k);
            vecTopPosition = getpixelposition(handles.stBTop);
            if vecKPosition(2) + vecKPosition(4) >= vecTopPosition(2)
                set(k, 'Visible', 'off');
            else
                set(k, 'Visible', 'on');
            end
        end
    end
    setpixelposition(handles.pbBTest, getpixelposition(handles.pbBTest) + vecChange);
    setpixelposition(handles.pbBCancel, getpixelposition(handles.pbBCancel) + vecChange);
    vecPosn = getpixelposition(handles.pbBTest);
    intScrollerValue = get(handles.slBYScroller, 'Value');
    set(handles.slBYScroller, 'Value', abs(vecPosn(2)));

end


% --- Executes when user attempts to close uiBSoluCheck.
function uiBSoluCheck_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to uiBSoluCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

% this does not do what it is supposed to! It should delete any added
% paths, then exit. But it doesn't do this.
% pause('on');
% pause(1/1000000);
% global bDone    
% global bFirstTime
% global sFilePath
% if ~bFirstTime
%     try
%         rmpath(sFilePath);
%     catch ME
%         fprintf('The paths for your files have NOT been deleted!\n%s', ME.message);
%     end
% end
% 
% if ~bDone
%     error('SoluCheck has exited violently, and results were not saved.');
% else
%     disp('SoluCheck has successfully exited.');
% end
delete(hObject);
