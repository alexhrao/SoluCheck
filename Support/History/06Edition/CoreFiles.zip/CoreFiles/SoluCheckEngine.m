function [bolPassed, strError, intIterationNumber, celArgs, celAnswers, celSolutions, vecCodeTime, vecSolnTime] = SoluCheckEngine(strFName, strFSolnName, intIterations, cDataType, varargin)
% SOLUCHECKENGINE Core of SoluCheck Platform
%
%       Normally only used within the SoluCheck User Interface, the SoluCheck
%       Engine can nevertheless be called directly from the command line.
%
%       Arguments:      
%               1. A string that has the function name (with .m).
%               2. A string that represents the Solution Name (with .p).
%               3. A whole number of iterations to be performed.
%               4. A cell array of the data types, from 1-6.
%               5. A variable input. Give your argument, then the step 
%                   size, in that order, for all arguments.
%
%       SoluCheck Engine will output: 
%               1. Boolean of passing status.
%               2. String that represents any errors.
%               3. Number of iterations done.
%               4. Cell array of arguments used.
%               5. Cell array of your answers.
%               6. Cell array of the solutions.
%               7. Vector with your code times.
%               8. Vector with the solution code time.
%
%       To use the SoluCheck Engine, you'll need to have somewhat advanced
%       knowledge of how MATLAB operates. It is recommended that you use the
%       SoluCheck GUI instead; this Engine use is only for experienced
%       programmers. Additionally, any errors you instigate will cause the
%       SoluCheck Engine to crash violently, without saving any results.
%
%       For more information, see the SoluCheck Documentation.
%   See also: SoluCheck, AdvancedOptions

    strError = '';
    intIterationNumber = 0;
    fSoluCheck = findobj('Tag', 'uiBSoluCheck');
    pause('on');
    
    if isappdata(fSoluCheck, 'stcSwitches')
        stcSwitches = getappdata(fSoluCheck, 'stcSwitches');
    else
        stcSwitches = struct('Profiler', false, ...
                             'Timing', false, ...
                             'SpecificSoln', false, ...
                             'ConstantSoln', false, ...
                             'Details', false, ...
                             'MaxMin', false, ...
                             'Exempt', false, ...
                             'ArrSize', false, ...
                             'Notifications', false);
    end
    
    if stcSwitches.Details
        fViewer = findobj('Tag', 'uiVViewer');
        hViewer = guidata(fViewer);
        cViewer = cell(intIterations, 1);
    end
    
    if stcSwitches.Profiler
        profile('on');
    else
        profile('off');
    end
    
    if stcSwitches.MaxMin
        celRanges = getappdata(findobj('Tag', 'uiBSoluCheck'), 'celRanges');
    end
    
    if stcSwitches.Exempt
        celExempt = getappdata(findobj('Tag', 'uiBSoluCheck'), 'celExempt');
        celStandIn = getappdata(findobj('Tag', 'uiBSoluCheck'), 'celStandIn');
    end
    
    try
        celArgs = cell(1, nargin(strFName));
        celSteps = cell(1, nargin(strFName));
    catch ME
        strError = sprintf('%s\n%s', ME.identifier, ME.message);
        bolPassed = false;
        celAnswers = cell(0, 0);
        celSolutions = cell(0, 0);
        celArgs = cell(0, 0);
        vecCodeTime = 0;
        vecSolnTime = 0;
        return
    end
    try
        celAnswers = cell(1, nargout(strFName));
        celSolutions = cell(1, nargout(strFSolnName));
    catch ME
        strError = sprintf('%s\n%s', ME.identifier, ME.message);
        bolPassed = false;
        celAnswers = cell(0, 0);
        celSolutions = cell(0, 0);
        return
    end
    
    bolPassed = true;

    i = 0;
    while i < length(varargin) / 2
        celSteps{1, i+1} = varargin{2 .* (i + 1)};
        celArgs{1, i+1} = varargin{2 .* i + 1};
        i = i + 1;
    end

    intArgs = length(celArgs);
    vecCodeTime = zeros(1, intIterations);
    vecSolnTime = zeros(1, intIterations);
    while intIterationNumber < intIterations
        intIterationNumber = intIterationNumber + 1;
        try
            tic();
            [celAnswers{:}] = feval(strFName, celArgs{:});
            vecCodeTime(intIterationNumber) = toc();
        catch ME
            strCodeErrorID = ME.identifier;
            strCodeErrorMsg = ME.message;
            try
                [celSolutions{:}] = feval(strFSolnName, celArgs{:});
                strError = sprintf('Code File:\n%s\n%s', ME.identifier, ME.message);
                bolPassed = false;
                if stcSwitches.Details
                    set(hViewer.tbVViewBox, 'String', strjoin(cViewer(intIterationNumber:-1:1, 1), '\n'));
                end
                break
            catch ME
                if strcmp(strCodeErrorID, ME.identifier)
                    bolPassed = true;
                else
                    bolPassed = false;
                    strError = sprintf('Code File:\n%s\n%s\n\nSolution File:\n%s\n%s', strCodeErrorID, strCodeErrorMsg, ME.identifier, ME.message);
                    if stcSwitches.Details
                        set(hViewer.tbVViewBox, 'String', strjoin(cViewer(intIterationNumber:-1:1, 1), '\n'));
                    end
                    break
                end
            end
        end
        
        try
            tic();
            [celSolutions{:}] = feval(strFSolnName, celArgs{:});
            vecSolnTime(intIterationNumber) = toc();
        catch ME
            strError = sprintf('Solution File:\n%s\n%s', ME.identifier, ME.message);
            bolPassed = false;
            if stcSwitches.Details
                set(hViewer.tbVViewBox, 'String', strjoin(cViewer(intIterationNumber:-1:1, 1), '\n'));
            end
            break
        end
        
        if isequal(celAnswers, celSolutions)
            if stcSwitches.Details
                cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Passed!', intIterationNumber);
            end
            i = 1;
            while i <= intArgs
                if (isnumeric(celSteps{1, i})) && (~iscell(celArgs{1, i}) || cDataType{i} ~= 6 || cDataType ~= 1)
                    varTest = celArgs{i} + celSteps{i};
                    
                    if stcSwitches.MaxMin
                        if ~any(any(varTest > celRanges{i}(2) | varTest < celRanges{i}(1)))
                            celArgs{1, i} = celArgs{1, i} + celSteps{1, i};
                        else
                            celArgs{1, i}(celArgs{1, i} == celRanges{i}(2)) = celRanges{i}(1);
                        end
                    else
                        celArgs{1, i} = celArgs{1, i} + celSteps{1, i};
                    end
                    
                    if stcSwitches.Exempt
                        for j = 1:length(celExempt{i})
                            if isequal(varTest, celExempt{i}{j})
                                celArgs{i}(celArgs{i}==celExempt{i}{j}) = celStandIn{i}{1};
                            end
                        end
                    end
                    
                    switch cDataType{i}
                        case 2
                            celArgs{1, i} = char(celArgs{1, i});
                            i = i + 1;
                        case 3
                            celArgs{1, i} = double(celArgs{1, i});
                            i = i + 1;
                        otherwise
                            i = i + 1;
                    end
                else
                    i = i + 1;
                end
            end
        else
            bolPassed = false;
            if stcSwitches.Details
                cViewer{intIterationNumber, 1} = sprintf('>> Argument #%d: Failed!', intIterationNumber);
            end
            break
        end
    end
    if stcSwitches.Details
        set(hViewer.tbVViewBox, 'String', strjoin(cViewer(intIterationNumber:-1:1, 1), '\n'));
    end
end